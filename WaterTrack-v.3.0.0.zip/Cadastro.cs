﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static WaterTrack.Login;

namespace WaterTrack
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();

            caixaNascimento.Value = new DateTime(2000, 1, 1);
        }

        private void labelSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void labelLogin_Click(object sender, EventArgs e)
        {
            Dispose();
            Login login = new Login();
            login.Show();
        }

        private void labelLogin_MouseEnter(object sender, EventArgs e)
        {
            labelLogin.Cursor = Cursors.Hand;
        }

        private void labelLogin_MouseLeave(object sender, EventArgs e)
        {
            labelCadastro.Cursor = Cursors.Default;
        }

        private void botaoCadastrar_Click(object sender, EventArgs e)
        {
            VerificacaoPreenchimento();

            InserirDadosNoBanco();

            Dispose();
            Login loginForm = new Login();
            loginForm.Show();
        }

        public void VerificacaoPreenchimento()
        {
            // Pegar os dados das caixas de texto
            string nome = caixaNome.Text;

            DateTime dataNascimento = caixaNascimento.Value;
            string celular = caixaCel.Text;
            string email = caixaEmail.Text;
            string senha = caixaSenha.Text;
            string confirmarSenha = caixaConfSenha.Text;

            // Verificar se os campos estão preenchidos
            if (string.IsNullOrEmpty(nome) || string.IsNullOrEmpty(celular) ||
                string.IsNullOrEmpty(email) || string.IsNullOrEmpty(senha) || string.IsNullOrEmpty(confirmarSenha))
            {
                MessageBox.Show("Por favor, preencha todos os campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Verificar se a senha e a confirmação de senha são iguais
            if (senha != confirmarSenha)
            {
                MessageBox.Show("As senhas não correspondem. Tente novamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Verifica se um dos checkboxes foi marcado
            if (!checkAluno.Checked && !checkProfessor.Checked)
            {
                MessageBox.Show("Por favor, selecione se é Aluno ou Professor.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        public void InserirDadosNoBanco()
        {
            string nome = caixaNome.Text;
            DateTime dataNascimento = caixaNascimento.Value;
            string celular = caixaCel.Text;
            string email = caixaEmail.Text;
            string senha = caixaSenha.Text;
            string nomeEscola = caixaEscola.Text;

            // Define a conexão com o banco de dados
            using (MySqlConnection conexao = new MySqlConnection("Server=127.0.0.1;Port=3306;Database=watertrack;User=root;Password="))
            {
                try
                {
                    conexao.Open();

                    if (checkProfessor.Checked)
                    {
                        // Query para inserir professor
                        string queryProfessor = "INSERT INTO professor (PROF_Nome, PROF_DatNasci, PROF_Cel, PROF_Email, PROF_Senha, PROF_ESC_Nome) " +
                                                "VALUES (@Nome, @DataNascimento, @Celular, @Email, @Senha, @NomeEscola)";

                        using (MySqlCommand cmd = new MySqlCommand(queryProfessor, conexao))
                        {
                            cmd.Parameters.AddWithValue("@Nome", nome);
                            cmd.Parameters.AddWithValue("@DataNascimento", dataNascimento.ToString("yyyy-MM-dd"));
                            cmd.Parameters.AddWithValue("@Celular", celular);
                            cmd.Parameters.AddWithValue("@Email", email);
                            cmd.Parameters.AddWithValue("@Senha", senha);
                            cmd.Parameters.AddWithValue("@NomeEscola", nomeEscola);

                            int result = cmd.ExecuteNonQuery();
                            if (result > 0)
                            {
                                MessageBox.Show("Cadastro de Professor realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Erro ao cadastrar o Professor. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else if (checkAluno.Checked)
                    {
                        // Query para inserir aluno
                        string queryAluno = "INSERT INTO aluno (ALU_Nome, ALU_DatNasci, ALU_Cel, ALU_Email, ALU_Senha, ALU_ESC_Nome) " +
                                            "VALUES (@Nome, @DataNascimento, @Celular, @Email, @Senha, @NomeEscola)";

                        using (MySqlCommand cmd = new MySqlCommand(queryAluno, conexao))
                        {
                            cmd.Parameters.AddWithValue("@Nome", nome);
                            cmd.Parameters.AddWithValue("@DataNascimento", dataNascimento.ToString("yyyy-MM-dd"));
                            cmd.Parameters.AddWithValue("@Celular", celular);
                            cmd.Parameters.AddWithValue("@Email", email);
                            cmd.Parameters.AddWithValue("@Senha", senha);
                            cmd.Parameters.AddWithValue("@NomeEscola", nomeEscola);

                            int result = cmd.ExecuteNonQuery();
                            if (result > 0)
                            {
                                MessageBox.Show("Cadastro de Aluno realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Erro ao cadastrar o Aluno. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private bool isPasswordVisible = false;
        private void mostrar_Hind_Click(object sender, EventArgs e)
        {
            if (isPasswordVisible)
            {
                // Oculta a senha
                caixaSenha.PasswordChar = '*'; // ou qualquer outro caractere
                mostrar_Hind1.Image = Properties.Resources.Olho_fechado; // Imagem de olho fechado
                isPasswordVisible = false;
            }
            else
            {
                // Revela a senha
                caixaSenha.PasswordChar = '\0'; // Mostra a senha
                mostrar_Hind1.Image = Properties.Resources.Olho_aberto; // Imagem de olho aberto
                isPasswordVisible = true;
            }
        }

        private void mostrar_Hind2_Click(object sender, EventArgs e)
        {
            if (isPasswordVisible)
            {
                // Oculta a senha
                caixaConfSenha.PasswordChar = '*'; // ou qualquer outro caractere
                mostrar_Hind2.Image = Properties.Resources.Olho_fechado; // Imagem de olho fechado
                isPasswordVisible = false;
            }
            else
            {
                // Revela a senha
                caixaConfSenha.PasswordChar = '\0'; // Mostra a senha
                mostrar_Hind2.Image = Properties.Resources.Olho_aberto; // Imagem de olho aberto
                isPasswordVisible = true;
            }
        }

        private void mostrar_Hind1_MouseEnter(object sender, EventArgs e)
        {
            mostrar_Hind1.Cursor = Cursors.Hand;
        }

        private void mostrar_Hind1_MouseLeave(object sender, EventArgs e)
        {
            mostrar_Hind1.Cursor = Cursors.Default;
        }

        private void mostrar_Hind2_MouseEnter(object sender, EventArgs e)
        {
            mostrar_Hind2.Cursor = Cursors.Hand;
        }

        private void mostrar_Hind2_MouseLeave(object sender, EventArgs e)
        {
            mostrar_Hind2.Cursor = Cursors.Default;
        }

        private void labelSair_MouseEnter(object sender, EventArgs e)
        {
            labelSair.Cursor = Cursors.Hand;
        }

        private void labelSair_MouseLeave(object sender, EventArgs e)
        {
            labelSair.Cursor = Cursors.Default;
        }

        private void botaoCadastrar_MouseEnter(object sender, EventArgs e)
        {
            botaoCadastrar.Cursor = Cursors.Hand;
        }

        private void botaoCadastrar_MouseLeave(object sender, EventArgs e)
        {
            botaoCadastrar.Cursor = Cursors.Default;
        }

        private void painelEsqurdo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void painelDireito_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
