﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WaterTrack
{
    public partial class SolicitacaoDeManutencao : Form
    {
        public SolicitacaoDeManutencao()
        {
            InitializeComponent();
        }

        private void SolicitacaoDeManutencao_Load(object sender, EventArgs e)
        {

        }

        private void labelTitulo_Click(object sender, EventArgs e)
        {

        }

        private void labelSair_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
