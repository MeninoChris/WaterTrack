﻿using MySqlConnector;
using System;
using System.Windows.Forms;

namespace WaterTrack
{
    public partial class ESQ_MinhaSenha : Form
    {
        public ESQ_MinhaSenha()
        {
            InitializeComponent();
        }

        private void botãoConfirmar_Click(object sender, EventArgs e)
        {
            string email = caixaEmail.Text;      // Caixa de texto onde o usuário digita o e-mail
            string novaSenha = caixaNovaSenha.Text;  // Caixa de texto onde o usuário insere a nova senha

            // Verifica se os campos de email e nova senha foram preenchidos
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(novaSenha))
            {
                MessageBox.Show("Por favor, preencha o email e a nova senha.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void ConfirmarSenhaBD()
        {
            using (MySqlConnection conexao = new MySqlConnection("Server=127.0.0.1;Port=3306;Database=watertrack;User=root;Password="))
            {
                string email = caixaEmail.Text;      // Caixa de texto onde o usuário digita o e-mail
                string novaSenha = caixaNovaSenha.Text;  // Caixa de texto onde o usuário insere a nova senha
                try
                {
                    conexao.Open();

                    // Verificar se o e-mail existe na tabela de funcionários
                    string queryFuncionario = "SELECT COUNT(*) FROM professor WHERE FUN_Email = @Email";
                    using (MySqlCommand cmd = new MySqlCommand(queryFuncionario, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        int funcionarioCount = Convert.ToInt32(cmd.ExecuteScalar());

                        // Se o e-mail existe na tabela de funcionários, atualiza a senha
                        if (funcionarioCount > 0)
                        {
                            string updateQuery = "UPDATE professor SET PROF_Senha = @NovaSenha WHERE PROF_Email = @Email";
                            using (MySqlCommand updateCmd = new MySqlCommand(updateQuery, conexao))
                            {
                                updateCmd.Parameters.AddWithValue("@NovaSenha", novaSenha);
                                updateCmd.Parameters.AddWithValue("@Email", email);

                                int result = updateCmd.ExecuteNonQuery();

                                if (result > 0)
                                {
                                    MessageBox.Show("Senha alterada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Erro ao alterar a senha. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            return; // Sai do método, pois a senha foi alterada com sucesso
                        }
                    }

                    // Verificar se o e-mail existe na tabela de alunos
                    string queryAluno = "SELECT COUNT(*) FROM aluno WHERE ALU_Email = @Email";
                    using (MySqlCommand cmd = new MySqlCommand(queryAluno, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        int alunoCount = Convert.ToInt32(cmd.ExecuteScalar());

                        // Se o e-mail existe na tabela de alunos, atualiza a senha
                        if (alunoCount > 0)
                        {
                            string updateQuery = "UPDATE aluno SET ALU_Senha = @NovaSenha WHERE ALU_Email = @Email";
                            using (MySqlCommand updateCmd = new MySqlCommand(updateQuery, conexao))
                            {
                                updateCmd.Parameters.AddWithValue("@NovaSenha", novaSenha);
                                updateCmd.Parameters.AddWithValue("@Email", email);

                                int result = updateCmd.ExecuteNonQuery();

                                if (result > 0)
                                {
                                    MessageBox.Show("Senha alterada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Erro ao alterar a senha. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("E-mail não encontrado. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ESQ_MinhaSenha_Load(object sender, EventArgs e)
        {

        }
    }
}
