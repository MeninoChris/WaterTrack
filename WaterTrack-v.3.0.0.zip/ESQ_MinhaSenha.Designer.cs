﻿namespace WaterTrack
{
    partial class ESQ_MinhaSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ESQ_MinhaSenha));
            this.labelEmail = new System.Windows.Forms.Label();
            this.caixaEmail = new System.Windows.Forms.TextBox();
            this.labelNovaSenha = new System.Windows.Forms.Label();
            this.caixaNovaSenha = new System.Windows.Forms.TextBox();
            this.labelConfSenha = new System.Windows.Forms.Label();
            this.caixaConfSenha = new System.Windows.Forms.TextBox();
            this.botãoConfirmar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.BackColor = System.Drawing.Color.Transparent;
            this.labelEmail.Location = new System.Drawing.Point(13, 33);
            this.labelEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(144, 17);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Insira seu Email:";
            // 
            // caixaEmail
            // 
            this.caixaEmail.Location = new System.Drawing.Point(16, 54);
            this.caixaEmail.Margin = new System.Windows.Forms.Padding(4);
            this.caixaEmail.Name = "caixaEmail";
            this.caixaEmail.Size = new System.Drawing.Size(211, 25);
            this.caixaEmail.TabIndex = 1;
            // 
            // labelNovaSenha
            // 
            this.labelNovaSenha.AutoSize = true;
            this.labelNovaSenha.BackColor = System.Drawing.Color.Transparent;
            this.labelNovaSenha.Location = new System.Drawing.Point(13, 105);
            this.labelNovaSenha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNovaSenha.Name = "labelNovaSenha";
            this.labelNovaSenha.Size = new System.Drawing.Size(184, 17);
            this.labelNovaSenha.TabIndex = 0;
            this.labelNovaSenha.Text = "Insira sua Nova Senha:";
            // 
            // caixaNovaSenha
            // 
            this.caixaNovaSenha.Location = new System.Drawing.Point(16, 126);
            this.caixaNovaSenha.Margin = new System.Windows.Forms.Padding(4);
            this.caixaNovaSenha.Name = "caixaNovaSenha";
            this.caixaNovaSenha.Size = new System.Drawing.Size(211, 25);
            this.caixaNovaSenha.TabIndex = 1;
            // 
            // labelConfSenha
            // 
            this.labelConfSenha.AutoSize = true;
            this.labelConfSenha.BackColor = System.Drawing.Color.Transparent;
            this.labelConfSenha.Location = new System.Drawing.Point(13, 174);
            this.labelConfSenha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelConfSenha.Name = "labelConfSenha";
            this.labelConfSenha.Size = new System.Drawing.Size(192, 17);
            this.labelConfSenha.TabIndex = 0;
            this.labelConfSenha.Text = "Confirme sua Nova Senha";
            // 
            // caixaConfSenha
            // 
            this.caixaConfSenha.Location = new System.Drawing.Point(16, 195);
            this.caixaConfSenha.Margin = new System.Windows.Forms.Padding(4);
            this.caixaConfSenha.Name = "caixaConfSenha";
            this.caixaConfSenha.Size = new System.Drawing.Size(211, 25);
            this.caixaConfSenha.TabIndex = 1;
            // 
            // botãoConfirmar
            // 
            this.botãoConfirmar.Location = new System.Drawing.Point(301, 184);
            this.botãoConfirmar.Margin = new System.Windows.Forms.Padding(4);
            this.botãoConfirmar.Name = "botãoConfirmar";
            this.botãoConfirmar.Size = new System.Drawing.Size(120, 44);
            this.botãoConfirmar.TabIndex = 2;
            this.botãoConfirmar.Text = "Confirmar";
            this.botãoConfirmar.UseVisualStyleBackColor = true;
            this.botãoConfirmar.Click += new System.EventHandler(this.botãoConfirmar_Click);
            // 
            // ESQ_MinhaSenha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 246);
            this.Controls.Add(this.botãoConfirmar);
            this.Controls.Add(this.caixaConfSenha);
            this.Controls.Add(this.labelConfSenha);
            this.Controls.Add(this.caixaNovaSenha);
            this.Controls.Add(this.labelNovaSenha);
            this.Controls.Add(this.caixaEmail);
            this.Controls.Add(this.labelEmail);
            this.Font = new System.Drawing.Font("JetBrains Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(479, 435);
            this.MinimizeBox = false;
            this.Name = "ESQ_MinhaSenha";
            this.Text = "Esqueci Minha Senha!";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox caixaEmail;
        private System.Windows.Forms.Label labelNovaSenha;
        private System.Windows.Forms.TextBox caixaNovaSenha;
        private System.Windows.Forms.Label labelConfSenha;
        private System.Windows.Forms.TextBox caixaConfSenha;
        private System.Windows.Forms.Button botãoConfirmar;
    }
}