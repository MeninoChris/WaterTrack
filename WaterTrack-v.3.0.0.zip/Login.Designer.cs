﻿namespace WaterTrack
{
    partial class Login
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.painelLogin = new System.Windows.Forms.Panel();
            this.botãoEntrar = new System.Windows.Forms.Button();
            this.labelCadastro = new System.Windows.Forms.Label();
            this.labelConta = new System.Windows.Forms.Label();
            this.labelSair = new System.Windows.Forms.Label();
            this.labelEsqueci = new System.Windows.Forms.Label();
            this.mostrar_Hind = new System.Windows.Forms.PictureBox();
            this.caixaSenha = new System.Windows.Forms.TextBox();
            this.caixaEmail = new System.Windows.Forms.TextBox();
            this.labelSenha = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelLogin = new System.Windows.Forms.Label();
            this.painelLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mostrar_Hind)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // painelLogin
            // 
            this.painelLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.painelLogin.Controls.Add(this.botãoEntrar);
            this.painelLogin.Controls.Add(this.labelCadastro);
            this.painelLogin.Controls.Add(this.labelConta);
            this.painelLogin.Controls.Add(this.labelSair);
            this.painelLogin.Controls.Add(this.labelEsqueci);
            this.painelLogin.Controls.Add(this.mostrar_Hind);
            this.painelLogin.Controls.Add(this.caixaSenha);
            this.painelLogin.Controls.Add(this.caixaEmail);
            this.painelLogin.Controls.Add(this.labelSenha);
            this.painelLogin.Controls.Add(this.labelEmail);
            this.painelLogin.Controls.Add(this.pictureBox1);
            this.painelLogin.Controls.Add(this.labelLogin);
            this.painelLogin.Location = new System.Drawing.Point(0, -1);
            this.painelLogin.Name = "painelLogin";
            this.painelLogin.Size = new System.Drawing.Size(752, 452);
            this.painelLogin.TabIndex = 0;
            this.painelLogin.Paint += new System.Windows.Forms.PaintEventHandler(this.painelLogin_Paint);
            // 
            // botãoEntrar
            // 
            this.botãoEntrar.BackColor = System.Drawing.Color.LightBlue;
            this.botãoEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoEntrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoEntrar.Location = new System.Drawing.Point(40, 284);
            this.botãoEntrar.Name = "botãoEntrar";
            this.botãoEntrar.Size = new System.Drawing.Size(229, 50);
            this.botãoEntrar.TabIndex = 8;
            this.botãoEntrar.Text = "Entrar";
            this.botãoEntrar.UseVisualStyleBackColor = false;
            this.botãoEntrar.Click += new System.EventHandler(this.botãoEntrar_Click);
            // 
            // labelCadastro
            // 
            this.labelCadastro.AutoSize = true;
            this.labelCadastro.BackColor = System.Drawing.Color.Transparent;
            this.labelCadastro.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCadastro.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labelCadastro.Location = new System.Drawing.Point(169, 258);
            this.labelCadastro.Name = "labelCadastro";
            this.labelCadastro.Size = new System.Drawing.Size(91, 16);
            this.labelCadastro.TabIndex = 6;
            this.labelCadastro.Text = "Cadastre-se!";
            this.labelCadastro.Click += new System.EventHandler(this.labelCadastro_Click);
            this.labelCadastro.MouseEnter += new System.EventHandler(this.labelCadastro_MouseEnter);
            this.labelCadastro.MouseLeave += new System.EventHandler(this.labelCadastro_MouseLeave);
            // 
            // labelConta
            // 
            this.labelConta.AutoSize = true;
            this.labelConta.BackColor = System.Drawing.Color.Transparent;
            this.labelConta.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConta.Location = new System.Drawing.Point(40, 258);
            this.labelConta.Name = "labelConta";
            this.labelConta.Size = new System.Drawing.Size(133, 16);
            this.labelConta.TabIndex = 5;
            this.labelConta.Text = "Não tem uma conta?";
            // 
            // labelSair
            // 
            this.labelSair.AutoSize = true;
            this.labelSair.BackColor = System.Drawing.Color.Transparent;
            this.labelSair.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSair.Location = new System.Drawing.Point(281, 415);
            this.labelSair.Name = "labelSair";
            this.labelSair.Size = new System.Drawing.Size(35, 16);
            this.labelSair.TabIndex = 7;
            this.labelSair.Text = "SAIR";
            this.labelSair.Click += new System.EventHandler(this.labelSair_Click);
            this.labelSair.MouseEnter += new System.EventHandler(this.labelSair_MouseEnter);
            this.labelSair.MouseLeave += new System.EventHandler(this.labelSair_MouseLeave);
            // 
            // labelEsqueci
            // 
            this.labelEsqueci.AutoSize = true;
            this.labelEsqueci.BackColor = System.Drawing.Color.Transparent;
            this.labelEsqueci.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEsqueci.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.labelEsqueci.Location = new System.Drawing.Point(12, 415);
            this.labelEsqueci.Name = "labelEsqueci";
            this.labelEsqueci.Size = new System.Drawing.Size(126, 16);
            this.labelEsqueci.TabIndex = 4;
            this.labelEsqueci.Text = "Esqueceu a senha?";
            this.labelEsqueci.Click += new System.EventHandler(this.labelEsqueci_Click);
            this.labelEsqueci.MouseEnter += new System.EventHandler(this.labelEsqueci_MouseEnter);
            this.labelEsqueci.MouseLeave += new System.EventHandler(this.labelEsqueci_MouseLeave);
            // 
            // mostrar_Hind
            // 
            this.mostrar_Hind.Location = new System.Drawing.Point(241, 223);
            this.mostrar_Hind.Name = "mostrar_Hind";
            this.mostrar_Hind.Size = new System.Drawing.Size(28, 22);
            this.mostrar_Hind.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mostrar_Hind.TabIndex = 4;
            this.mostrar_Hind.TabStop = false;
            this.mostrar_Hind.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // caixaSenha
            // 
            this.caixaSenha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.caixaSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caixaSenha.Location = new System.Drawing.Point(40, 223);
            this.caixaSenha.Name = "caixaSenha";
            this.caixaSenha.PasswordChar = '*';
            this.caixaSenha.Size = new System.Drawing.Size(195, 20);
            this.caixaSenha.TabIndex = 3;
            // 
            // caixaEmail
            // 
            this.caixaEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caixaEmail.Location = new System.Drawing.Point(40, 160);
            this.caixaEmail.Name = "caixaEmail";
            this.caixaEmail.Size = new System.Drawing.Size(229, 20);
            this.caixaEmail.TabIndex = 1;
            // 
            // labelSenha
            // 
            this.labelSenha.AutoSize = true;
            this.labelSenha.BackColor = System.Drawing.Color.Transparent;
            this.labelSenha.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSenha.Location = new System.Drawing.Point(36, 199);
            this.labelSenha.Name = "labelSenha";
            this.labelSenha.Size = new System.Drawing.Size(49, 16);
            this.labelSenha.TabIndex = 2;
            this.labelSenha.Text = "Senha:";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.BackColor = System.Drawing.Color.Transparent;
            this.labelEmail.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(36, 135);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(91, 16);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email/Login:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(322, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(430, 452);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.BackColor = System.Drawing.Color.Transparent;
            this.labelLogin.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogin.Location = new System.Drawing.Point(124, 52);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(108, 61);
            this.labelLogin.TabIndex = 0;
            this.labelLogin.Text = "Login";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 450);
            this.Controls.Add(this.painelLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.painelLogin.ResumeLayout(false);
            this.painelLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mostrar_Hind)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel painelLogin;
        private System.Windows.Forms.Label labelSenha;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.TextBox caixaSenha;
        private System.Windows.Forms.TextBox caixaEmail;
        private System.Windows.Forms.PictureBox mostrar_Hind;
        private System.Windows.Forms.Label labelEsqueci;
        private System.Windows.Forms.Label labelSair;
        private System.Windows.Forms.Label labelCadastro;
        private System.Windows.Forms.Label labelConta;
        private System.Windows.Forms.Button botãoEntrar;
    }
}

