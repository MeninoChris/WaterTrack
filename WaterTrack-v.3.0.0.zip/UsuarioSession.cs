﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    internal class UsuarioSession
    {
        public static int ID { get; set; }
        public static string TipoUsuario { get; set; } // "Aluno" ou "Professor"
    }
}
