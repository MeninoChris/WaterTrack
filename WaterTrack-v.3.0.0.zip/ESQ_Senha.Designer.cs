﻿namespace WaterTrack
{
    partial class ESQ_Senha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ESQ_Senha));
            this.labelEmail = new System.Windows.Forms.Label();
            this.caixaEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.caixaCodigo = new System.Windows.Forms.TextBox();
            this.botãoEnviar = new System.Windows.Forms.Button();
            this.botãoConfirmar = new System.Windows.Forms.Button();
            this.botãoVoltar = new System.Windows.Forms.Button();
            this.timeVCODE = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(28, 31);
            this.labelEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(42, 15);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email:";
            // 
            // caixaEmail
            // 
            this.caixaEmail.Location = new System.Drawing.Point(31, 51);
            this.caixaEmail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaEmail.Name = "caixaEmail";
            this.caixaEmail.Size = new System.Drawing.Size(289, 21);
            this.caixaEmail.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Codigo:";
            // 
            // caixaCodigo
            // 
            this.caixaCodigo.Enabled = false;
            this.caixaCodigo.Location = new System.Drawing.Point(31, 122);
            this.caixaCodigo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaCodigo.Name = "caixaCodigo";
            this.caixaCodigo.Size = new System.Drawing.Size(157, 21);
            this.caixaCodigo.TabIndex = 1;
            // 
            // botãoEnviar
            // 
            this.botãoEnviar.Location = new System.Drawing.Point(346, 49);
            this.botãoEnviar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.botãoEnviar.Name = "botãoEnviar";
            this.botãoEnviar.Size = new System.Drawing.Size(88, 29);
            this.botãoEnviar.TabIndex = 2;
            this.botãoEnviar.Text = "Enviar";
            this.botãoEnviar.UseVisualStyleBackColor = true;
            this.botãoEnviar.Click += new System.EventHandler(this.botãoEnviar_Click);
            // 
            // botãoConfirmar
            // 
            this.botãoConfirmar.Enabled = false;
            this.botãoConfirmar.Location = new System.Drawing.Point(31, 155);
            this.botãoConfirmar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.botãoConfirmar.Name = "botãoConfirmar";
            this.botãoConfirmar.Size = new System.Drawing.Size(88, 29);
            this.botãoConfirmar.TabIndex = 3;
            this.botãoConfirmar.Text = "Confirmar";
            this.botãoConfirmar.UseVisualStyleBackColor = true;
            this.botãoConfirmar.Click += new System.EventHandler(this.botãoConfirmar_Click);
            // 
            // botãoVoltar
            // 
            this.botãoVoltar.Location = new System.Drawing.Point(346, 155);
            this.botãoVoltar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.botãoVoltar.Name = "botãoVoltar";
            this.botãoVoltar.Size = new System.Drawing.Size(88, 29);
            this.botãoVoltar.TabIndex = 4;
            this.botãoVoltar.Text = "Voltar";
            this.botãoVoltar.UseVisualStyleBackColor = true;
            // 
            // ESQ_Senha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 207);
            this.Controls.Add(this.botãoVoltar);
            this.Controls.Add(this.botãoConfirmar);
            this.Controls.Add(this.botãoEnviar);
            this.Controls.Add(this.caixaCodigo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.caixaEmail);
            this.Controls.Add(this.labelEmail);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ESQ_Senha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Esqueci Minha Senha!";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox caixaEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox caixaCodigo;
        private System.Windows.Forms.Button botãoEnviar;
        private System.Windows.Forms.Button botãoConfirmar;
        private System.Windows.Forms.Button botãoVoltar;
        private System.Windows.Forms.Timer timeVCODE;
    }
}