﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Windows.Forms;
using WaterTrack.Resources;

namespace WaterTrack
{
    public partial class Menu_Alun : Form
    {
        public Menu_Alun()
        {
            InitializeComponent();

            // Nome do aplicativo e versão
            string appName = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product;
            string appVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();

            // Exibir o nome e a versão na Label
            labelVersão.Text = $"{appName} Version: {appVersion}";
        }

        private void botãoÁgua_Click(object sender, System.EventArgs e)
        {

            InfoAguaAlunos infoAguaAlunos = new InfoAguaAlunos();
            infoAguaAlunos.Show();

        }

        private void AlterarDadosMenu_Click(object sender, System.EventArgs e)
        {
            AltDados alterar = new AltDados();
            alterar.Show();
        }

        private void AlterarSenhaMenu_Click(object sender, System.EventArgs e)
        {
            ESQ_MinhaSenha senha = new ESQ_MinhaSenha();
            senha.Show();
        }

        private void botãoProblema_Click(object sender, System.EventArgs e)
        {

            SolicitacaoDeManutencao solicitacao = new SolicitacaoDeManutencao();
            solicitacao.Show();

        }

        private void botãoRecomendação_Click(object sender, System.EventArgs e)
        {

            FeedBacks feedBacks = new FeedBacks();
            feedBacks.Show();

        }

        private void botãoSobre_Click(object sender, System.EventArgs e)
        {

            Sobre sobre = new Sobre();
            sobre.Show();

        }

        private void FazerLogoutMenu_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Show();
        }
    }
}
