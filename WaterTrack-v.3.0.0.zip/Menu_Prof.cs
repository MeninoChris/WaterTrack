﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WaterTrack;
using WaterTrack.Resources;

namespace WaterTrack
{
    public partial class Menu_Prof : Form
    {
        public Menu_Prof()
        {
            InitializeComponent();

            // Nome do aplicativo e versão
            string appName = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product;
            string appVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();

            // Exibir o nome e a versão na Label
            labelVersão.Text = $"{appName} Version: {appVersion}";
        }

        private void Menu_Func_Load(object sender, EventArgs e)
        {

        }

        private void botãoÁgua_Click(object sender, EventArgs e)
        {

            InfoAguaProf infoAguaFunc = new InfoAguaProf();
            infoAguaFunc.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SolicitacaoDeManutencao solicitacaoDeManutencao = new SolicitacaoDeManutencao();
            solicitacaoDeManutencao.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {

            FeedBacks feedBacks = new FeedBacks();
            feedBacks.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Mapa_ESC mapa_ESC = new Mapa_ESC();
            mapa_ESC.Show();

        }

        private void botãoProblema_Click(object sender, EventArgs e)
        {

            Relatorio relatorio = new Relatorio();
            relatorio.Show();

        }

        private void botãoSobre_Click(object sender, EventArgs e)
        {

            Sobre sobre = new Sobre();
            sobre.Show();

        }

        private void FazerLogoutMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Show();
        }

        private void AlterarSenhaMenu_Click(object sender, EventArgs e)
        {

            ESQ_MinhaSenha eSQ_MinhaSenha = new ESQ_MinhaSenha();
            eSQ_MinhaSenha.Show();

        }

        private void AlterarDadosMenu_Click(object sender, EventArgs e)
        {
            AltDados alterar = new AltDados();
            alterar.Show();
        }

        private void ConfiguraçõesMenu_Click(object sender, EventArgs e)
        {

        }

        private void contatarFornecedorToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            Fornecedor fornecedor = new Fornecedor();
            fornecedor.Show();

        }

        private void gerarRelatorioToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Relatorio relatorio = new Relatorio();
            relatorio.Show();

        }

        private void alertasAvisosToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Alertas alertas = new Alertas();
            alertas.Show();

        }

        private void labelSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void labelSair_MouseEnter(object sender, EventArgs e)
        {
            // Muda o cursor para "Mão" (indicando que é clicável)
            labelSair.Cursor = Cursors.Hand;

            // Opcional: Mudar a cor da label para simular um link ou botão
            labelSair.ForeColor = Color.Blue;
        }

        private void labelSair_MouseLeave(object sender, EventArgs e)
        {
            // Muda o cursor para "Mão" (indicando que é clicável)
            labelSair.Cursor = Cursors.Hand;

            // Opcional: Mudar a cor da label para simular um link ou botão
            labelSair.ForeColor = Color.Black;
        }
    }
}
