﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WaterTrack.Resources
{
    public partial class Alertas : Form
    {
        public Alertas()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Alertas_Load(object sender, EventArgs e)
        {

        }

        private void labelSair_Click(object sender, EventArgs e)
        {

            this.Hide();

        }
    }
}
