﻿namespace WaterTrack.Resources
{
    partial class Reportar
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.ContaMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AlterarDadosMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AlterarSenhaMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.FazerLogoutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfiguraçõesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.SuporteMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.funçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alertasAvisosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerarRelatorioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contatarFornecedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PainelLayout = new System.Windows.Forms.FlowLayoutPanel();
            this.labelTitulo = new System.Windows.Forms.Label();
            this.labelSair = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Menu.SuspendLayout();
            this.PainelLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.Location = new System.Drawing.Point(12, 105);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(353, 20);
            this.textBox1.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 23;
            this.label2.Text = "Assunto";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 58);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Data";
            // 
            // Menu
            // 
            this.Menu.BackColor = System.Drawing.Color.Transparent;
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ContaMenu,
            this.ConfiguraçõesMenu,
            this.SuporteMenu,
            this.funçõesToolStripMenuItem});
            this.Menu.Location = new System.Drawing.Point(0, 0);
            this.Menu.Name = "Menu";
            this.Menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.Menu.Size = new System.Drawing.Size(734, 28);
            this.Menu.TabIndex = 19;
            this.Menu.Text = "menuStrip1";
            // 
            // ContaMenu
            // 
            this.ContaMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AlterarDadosMenu,
            this.AlterarSenhaMenu,
            this.FazerLogoutMenu});
            this.ContaMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContaMenu.Name = "ContaMenu";
            this.ContaMenu.Size = new System.Drawing.Size(69, 24);
            this.ContaMenu.Text = "Conta";
            // 
            // AlterarDadosMenu
            // 
            this.AlterarDadosMenu.Name = "AlterarDadosMenu";
            this.AlterarDadosMenu.Size = new System.Drawing.Size(189, 24);
            this.AlterarDadosMenu.Text = "Alterar Dados";
            // 
            // AlterarSenhaMenu
            // 
            this.AlterarSenhaMenu.Name = "AlterarSenhaMenu";
            this.AlterarSenhaMenu.Size = new System.Drawing.Size(189, 24);
            this.AlterarSenhaMenu.Text = "Alterar Senha";
            // 
            // FazerLogoutMenu
            // 
            this.FazerLogoutMenu.Name = "FazerLogoutMenu";
            this.FazerLogoutMenu.Size = new System.Drawing.Size(189, 24);
            this.FazerLogoutMenu.Text = "Fazer Logout";
            // 
            // ConfiguraçõesMenu
            // 
            this.ConfiguraçõesMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfiguraçõesMenu.Name = "ConfiguraçõesMenu";
            this.ConfiguraçõesMenu.Size = new System.Drawing.Size(137, 24);
            this.ConfiguraçõesMenu.Text = "Configurações";
            // 
            // SuporteMenu
            // 
            this.SuporteMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SuporteMenu.Name = "SuporteMenu";
            this.SuporteMenu.Size = new System.Drawing.Size(85, 24);
            this.SuporteMenu.Text = "Suporte";
            // 
            // funçõesToolStripMenuItem
            // 
            this.funçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alertasAvisosToolStripMenuItem,
            this.gerarRelatorioToolStripMenuItem,
            this.contatarFornecedorToolStripMenuItem});
            this.funçõesToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.funçõesToolStripMenuItem.Name = "funçõesToolStripMenuItem";
            this.funçõesToolStripMenuItem.Size = new System.Drawing.Size(90, 24);
            this.funçõesToolStripMenuItem.Text = "Funções";
            // 
            // alertasAvisosToolStripMenuItem
            // 
            this.alertasAvisosToolStripMenuItem.Name = "alertasAvisosToolStripMenuItem";
            this.alertasAvisosToolStripMenuItem.Size = new System.Drawing.Size(245, 24);
            this.alertasAvisosToolStripMenuItem.Text = "Alertas/Avisos";
            // 
            // gerarRelatorioToolStripMenuItem
            // 
            this.gerarRelatorioToolStripMenuItem.Name = "gerarRelatorioToolStripMenuItem";
            this.gerarRelatorioToolStripMenuItem.Size = new System.Drawing.Size(245, 24);
            this.gerarRelatorioToolStripMenuItem.Text = "Gerar Relatorio";
            // 
            // contatarFornecedorToolStripMenuItem
            // 
            this.contatarFornecedorToolStripMenuItem.Name = "contatarFornecedorToolStripMenuItem";
            this.contatarFornecedorToolStripMenuItem.Size = new System.Drawing.Size(245, 24);
            this.contatarFornecedorToolStripMenuItem.Text = "Contatar Fornecedor";
            // 
            // PainelLayout
            // 
            this.PainelLayout.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.PainelLayout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PainelLayout.Controls.Add(this.labelTitulo);
            this.PainelLayout.Location = new System.Drawing.Point(498, 28);
            this.PainelLayout.Margin = new System.Windows.Forms.Padding(0);
            this.PainelLayout.Name = "PainelLayout";
            this.PainelLayout.Size = new System.Drawing.Size(236, 424);
            this.PainelLayout.TabIndex = 20;
            // 
            // labelTitulo
            // 
            this.labelTitulo.AutoSize = true;
            this.labelTitulo.BackColor = System.Drawing.Color.Transparent;
            this.labelTitulo.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitulo.ForeColor = System.Drawing.Color.Black;
            this.labelTitulo.Location = new System.Drawing.Point(4, 0);
            this.labelTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTitulo.Name = "labelTitulo";
            this.labelTitulo.Size = new System.Drawing.Size(158, 61);
            this.labelTitulo.TabIndex = 2;
            this.labelTitulo.Text = "Reportar";
            // 
            // labelSair
            // 
            this.labelSair.AutoSize = true;
            this.labelSair.BackColor = System.Drawing.Color.Transparent;
            this.labelSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSair.Location = new System.Drawing.Point(12, 384);
            this.labelSair.Name = "labelSair";
            this.labelSair.Size = new System.Drawing.Size(46, 18);
            this.labelSair.TabIndex = 33;
            this.labelSair.Text = "Voltar";
            this.labelSair.Click += new System.EventHandler(this.labelSair_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(438, 384);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 18);
            this.label3.TabIndex = 34;
            this.label3.Text = "Enviar";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Reportar
            // 
            this.ClientSize = new System.Drawing.Size(734, 411);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelSair);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Menu);
            this.Controls.Add(this.PainelLayout);
            this.MaximumSize = new System.Drawing.Size(750, 450);
            this.Name = "Reportar";
            this.Load += new System.EventHandler(this.Reportar_Load);
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            this.PainelLayout.ResumeLayout(false);
            this.PainelLayout.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem ContaMenu;
        private System.Windows.Forms.ToolStripMenuItem AlterarDadosMenu;
        private System.Windows.Forms.ToolStripMenuItem AlterarSenhaMenu;
        private System.Windows.Forms.ToolStripMenuItem FazerLogoutMenu;
        private System.Windows.Forms.ToolStripMenuItem ConfiguraçõesMenu;
        private System.Windows.Forms.ToolStripMenuItem SuporteMenu;
        private System.Windows.Forms.ToolStripMenuItem funçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alertasAvisosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerarRelatorioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contatarFornecedorToolStripMenuItem;
        private System.Windows.Forms.FlowLayoutPanel PainelLayout;
        private System.Windows.Forms.Label labelTitulo;
        private System.Windows.Forms.Label labelSair;
        private System.Windows.Forms.Label label3;
    }
}
