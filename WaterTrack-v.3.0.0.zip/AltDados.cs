﻿using MySqlConnector;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using $safeprojectname$;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WaterTrack
{
    public partial class AltDados : Form
    {
        public AltDados()
        {
            InitializeComponent();
        }
        private void CarregarDados()
        {
            int usuarioId = UsuarioSession.ID;

            using (MySqlConnection conexao = new MySqlConnection("Server=127.0.0.1;Port=3306;Database=watertrack2;User=root;Password="))
            {
                try
                {
                    conexao.Open();

                    // Verifica se o usuário é Aluno ou Professor
                    string tabela = UsuarioSession.TipoUsuario == "Aluno" ? "aluno" : "professor";
                    string query = $"SELECT * FROM {tabela} WHERE {(UsuarioSession.TipoUsuario == "Aluno" ? "ALU_ID" : "PROF_ID")} = @ID"; // Usando o nome da coluna correto

                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@ID", usuarioId);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                if (UsuarioSession.TipoUsuario == "Aluno")
                                {
                                    caixaNome.Text = reader["ALU_Nome"].ToString();
                                    caixaNumero.Text = reader["ALU_Cel"].ToString();
                                    caixaEmail.Text = reader["ALU_Email"].ToString();
                                    caixaEscola.Text = reader["ALU_ESC_Nome"].ToString();
                                    caixaCurso.Text = reader["ALU_Curso"]?.ToString() ?? "";
                                    caixaNascimento.Value = Convert.ToDateTime(reader["ALU_DatNasci"]);
                                }
                                else // É professor
                                {
                                    caixaNome.Text = reader["PROF_Nome"].ToString();
                                    caixaNumero.Text = reader["PROF_Cel"].ToString();
                                    caixaEmail.Text = reader["PROF_Email"].ToString();
                                    caixaEscola.Text = reader["PROF_ESC_Nome"].ToString();
                                    caixaCurso.Text = reader["PROF_Curso"]?.ToString() ?? "";
                                    caixaNascimento.Value = Convert.ToDateTime(reader["PROF_DatNasci"]);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Usuário não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void RemoverFotoDoBanco()
        {
            using (MySqlConnection conexao =
                   new MySqlConnection("Server=127.0.0.1;Port=3306;Database=watertrack2;User=root;Password="))
            {
                try
                {
                    conexao.Open();
                    string query;

                    if (UsuarioSession.TipoUsuario == "Aluno")
                    {
                        query = "UPDATE aluno SET ALU_Foto = NULL WHERE ALU_ID = @ID";
                    }
                    else // Professor
                    {
                        query = "UPDATE professor SET PROF_Foto = NULL WHERE PROF_ID = @ID";
                    }

                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@ID", caixaID.Text);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Foto removida com sucesso!", "Sucesso", MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Erro ao remover a foto.", "Erro", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao remover a foto: " + ex.Message, "Erro", MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }


        private void Conta_Load(object sender, EventArgs e)
        {
             CarregarDados();
        }


        private void botãoAtualizar_Click(object sender, EventArgs e)
        {
            // Atualizar os dados no banco de dados
            using (MySqlConnection conexao = new MySqlConnection("Server=127.0.0.1;Port=3306;Database=watertrack2;User=root;Password="))
            {
                try
                {
                    conexao.Open();

                    string query = string.Empty;

                    // Define a query apropriada com base no tipo de usuário
                    if (UsuarioSession.TipoUsuario == "Aluno")
                    {
                        query = "UPDATE aluno SET ALU_Nome = @Nome, ALU_Email = @Email, ALU_Curso = @Curso, ALU_ESC_Nome = @Escola, ALU_DatNasci = @DataNascimento WHERE ALU_ID = @Id";
                    }
                    else if (UsuarioSession.TipoUsuario == "Professor")
                    {
                        query = "UPDATE professor SET PROF_Nome = @Nome, PROF_Email = @Email, PROF_Curso = @Curso, PROF_ESC_Nome = @Escola, PROF_DatNasci = @DataNascimento WHERE PROF_ID = @Id";
                    }

                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Id", UsuarioSession.ID);
                        cmd.Parameters.AddWithValue("@Nome", caixaNome.Text);
                        cmd.Parameters.AddWithValue("@Email", caixaEmail.Text);
                        cmd.Parameters.AddWithValue("@Curso", caixaCurso.Text);
                        cmd.Parameters.AddWithValue("@Escola", caixaEscola.Text);
                        cmd.Parameters.AddWithValue("@DataNascimento", caixaNascimento.Value);

                        int result = cmd.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Dados atualizados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Nenhuma alteração foi feita.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Foto.Image = new Bitmap(openFileDialog.FileName);
                    // Salve o caminho ou a imagem em sua base de dados, se necessário
                }
            }
        }

        private void botãoRemover_Click(object sender, EventArgs e)
        {
            Foto.Image = null; // Limpa a imagem do PictureBox

            // Aqui você pode também atualizar o banco de dados para remover a foto
            RemoverFotoDoBanco();
        }
    }
}
