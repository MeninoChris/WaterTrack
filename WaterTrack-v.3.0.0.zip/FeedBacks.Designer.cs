﻿namespace WaterTrack.Resources
{
    partial class FeedBacks
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FeedBacks));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Autor = new System.Windows.Forms.Label();
            this.Assunto = new System.Windows.Forms.Label();
            this.feedback1 = new System.Windows.Forms.Label();
            this.autor1 = new System.Windows.Forms.Label();
            this.feedback2 = new System.Windows.Forms.Label();
            this.autor2 = new System.Windows.Forms.Label();
            this.feedback3 = new System.Windows.Forms.Label();
            this.autor3 = new System.Windows.Forms.Label();
            this.labelSair = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29F));
            this.tableLayoutPanel1.Controls.Add(this.Autor, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.Assunto, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.feedback1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.autor1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.feedback2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.autor2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.feedback3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.autor3, 1, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(45, 20);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.256881F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.58104F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.58104F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.58104F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(645, 361);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // Autor
            // 
            this.Autor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Autor.BackColor = System.Drawing.Color.Transparent;
            this.Autor.Location = new System.Drawing.Point(460, 5);
            this.Autor.Name = "Autor";
            this.Autor.Size = new System.Drawing.Size(180, 22);
            this.Autor.TabIndex = 1;
            this.Autor.Text = "Autor";
            this.Autor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Assunto
            // 
            this.Assunto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Assunto.BackColor = System.Drawing.Color.Transparent;
            this.Assunto.Location = new System.Drawing.Point(5, 6);
            this.Assunto.Name = "Assunto";
            this.Assunto.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Assunto.Size = new System.Drawing.Size(447, 20);
            this.Assunto.TabIndex = 0;
            this.Assunto.Text = "Assunto";
            this.Assunto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // feedback1
            // 
            this.feedback1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.feedback1.AutoSize = true;
            this.feedback1.BackColor = System.Drawing.Color.Transparent;
            this.feedback1.Location = new System.Drawing.Point(5, 79);
            this.feedback1.Name = "feedback1";
            this.feedback1.Size = new System.Drawing.Size(447, 13);
            this.feedback1.TabIndex = 2;
            this.feedback1.Text = "label3";
            // 
            // autor1
            // 
            this.autor1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.autor1.AutoSize = true;
            this.autor1.BackColor = System.Drawing.Color.Transparent;
            this.autor1.Location = new System.Drawing.Point(460, 79);
            this.autor1.Name = "autor1";
            this.autor1.Size = new System.Drawing.Size(180, 13);
            this.autor1.TabIndex = 3;
            this.autor1.Text = "label4";
            // 
            // feedback2
            // 
            this.feedback2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.feedback2.AutoSize = true;
            this.feedback2.BackColor = System.Drawing.Color.Transparent;
            this.feedback2.Location = new System.Drawing.Point(5, 188);
            this.feedback2.Name = "feedback2";
            this.feedback2.Size = new System.Drawing.Size(447, 13);
            this.feedback2.TabIndex = 4;
            this.feedback2.Text = "label5";
            // 
            // autor2
            // 
            this.autor2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.autor2.AutoSize = true;
            this.autor2.BackColor = System.Drawing.Color.Transparent;
            this.autor2.Location = new System.Drawing.Point(460, 188);
            this.autor2.Name = "autor2";
            this.autor2.Size = new System.Drawing.Size(180, 13);
            this.autor2.TabIndex = 5;
            this.autor2.Text = "label6";
            // 
            // feedback3
            // 
            this.feedback3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.feedback3.AutoSize = true;
            this.feedback3.BackColor = System.Drawing.Color.Transparent;
            this.feedback3.Location = new System.Drawing.Point(5, 298);
            this.feedback3.Name = "feedback3";
            this.feedback3.Size = new System.Drawing.Size(447, 13);
            this.feedback3.TabIndex = 6;
            this.feedback3.Text = "label7";
            // 
            // autor3
            // 
            this.autor3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.autor3.AutoSize = true;
            this.autor3.BackColor = System.Drawing.Color.Transparent;
            this.autor3.Location = new System.Drawing.Point(460, 298);
            this.autor3.Name = "autor3";
            this.autor3.Size = new System.Drawing.Size(180, 13);
            this.autor3.TabIndex = 7;
            this.autor3.Text = "label8";
            // 
            // labelSair
            // 
            this.labelSair.AutoSize = true;
            this.labelSair.BackColor = System.Drawing.Color.Transparent;
            this.labelSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSair.Location = new System.Drawing.Point(12, 384);
            this.labelSair.Name = "labelSair";
            this.labelSair.Size = new System.Drawing.Size(46, 18);
            this.labelSair.TabIndex = 34;
            this.labelSair.Text = "Voltar";
            this.labelSair.Click += new System.EventHandler(this.labelSair_Click);
            // 
            // FeedBacks
            // 
            this.ClientSize = new System.Drawing.Size(734, 411);
            this.Controls.Add(this.labelSair);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(750, 450);
            this.MinimizeBox = false;
            this.Name = "FeedBacks";
            this.Load += new System.EventHandler(this.FeedBacks_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label Autor;
        private System.Windows.Forms.Label Assunto;
        private System.Windows.Forms.Label feedback1;
        private System.Windows.Forms.Label autor1;
        private System.Windows.Forms.Label feedback2;
        private System.Windows.Forms.Label autor2;
        private System.Windows.Forms.Label feedback3;
        private System.Windows.Forms.Label autor3;
        private System.Windows.Forms.Label labelSair;
    }
}
