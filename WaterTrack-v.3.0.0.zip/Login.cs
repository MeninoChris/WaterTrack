﻿using MySqlConnector;
using Mysqlx.Session;
using MySqlX.XDevAPI.Common;
using System;
using System.Drawing;
using System.Net;
using System.Windows.Forms;
using $safeprojectname$;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WaterTrack
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private bool isPasswordVisible = false;
        private void pictureBox2_Click(object sender, EventArgs e)
        {

            if (isPasswordVisible)
            {
                // Oculta a senha
                caixaSenha.PasswordChar = '*'; // ou qualquer outro caractere
                mostrar_Hind.Image = Properties.Resources.Olho_fechado; // Imagem de olho fechado
                isPasswordVisible = false;
            }
            else
            {
                // Revela a senha
                caixaSenha.PasswordChar = '\0'; // Mostra a senha
                mostrar_Hind.Image = Properties.Resources.Olho_aberto; // Imagem de olho aberto
                isPasswordVisible = true;
            }

        }

        private void labelEsqueci_Click(object sender, EventArgs e)
        {

            this.Hide();
            ESQ_Senha esqueci = new ESQ_Senha();
            esqueci.Show();

        }

        private void labelSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void labelSair_MouseEnter(object sender, EventArgs e)
        {
            // Muda o cursor para "Mão" (indicando que é clicável)
            labelSair.Cursor = Cursors.Hand;

            // Opcional: Mudar a cor da label para simular um link ou botão
            labelSair.ForeColor = Color.Blue;
        }

        private void labelSair_MouseLeave(object sender, EventArgs e)
        {
            // Retorna o cursor ao padrão
            labelSair.Cursor = Cursors.Default;

            // Opcional: Voltar a cor original da label
            labelSair.ForeColor = Color.Black; // ou a cor original que você estiver usando
        }

        private void labelCadastro_MouseEnter(object sender, EventArgs e)
        {
            // Muda o cursor para "Mão" (indicando que é clicável)
            labelCadastro.Cursor = Cursors.Hand;


        }

        private void labelCadastro_MouseLeave(object sender, EventArgs e)
        {
            labelCadastro.Cursor = Cursors.Default;
        }




        private void labelCadastro_Click(object sender, EventArgs e)
        {
            this.Hide();
            Cadastro cadastro = new Cadastro();
            cadastro.Show();
        }

        private void botãoEntrar_MouseEnter(object sender, EventArgs e)
        {
            botãoEntrar.Cursor = Cursors.Hand;
        }

        private void botãoEntrar_MouseLeave(object sender, EventArgs e)
        {
            botãoEntrar.Cursor = Cursors.Default;
        }

        private void mostrar_Hind_MouseEnter(object sender, EventArgs e)
        {
            mostrar_Hind.Cursor = Cursors.Hand;
        }

        private void mostrar_Hind_MouseLeave(object sender, EventArgs e)
        {
            mostrar_Hind.Cursor = Cursors.Default;
        }


        private void botãoEntrar_Click(object sender, EventArgs e)
        {
            string email = caixaEmail.Text;
            string senha = caixaSenha.Text;

            // Verifica se os campos de email e senha foram preenchidos
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(senha))
            {
                MessageBox.Show("Por favor, preencha os campos de email e senha.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Primeiro tenta verificar o cadastro na tabela de funcionário
            using (MySqlConnection conexao = new MySqlConnection("Server=127.0.0.1;Port=3306;Database=watertrack2;User=root;Password="))
            {
                try
                {
                    conexao.Open();

                    // Tenta verificar o aluno
                    string queryAluno = "SELECT COUNT(*) FROM aluno WHERE ALU_Email = @Email AND ALU_Senha = @Senha";
                    using (MySqlCommand cmd = new MySqlCommand(queryAluno, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Senha", senha);
                        int alunoCount = Convert.ToInt32(cmd.ExecuteScalar());

                        if (alunoCount > 0)
                        {
                            UsuarioSession.ID = Convert.ToInt32(alunoCount);
                            UsuarioSession.TipoUsuario = "Aluno";
                            MessageBox.Show("Login como aluno bem-sucedido!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Menu_Alun painelAluno = new Menu_Alun();
                            painelAluno.Show();
                            this.Hide();
                            return;
                        }
                    }

                    // Se não encontrou aluno, tenta verificar o professor
                    string queryProfessor = "SELECT COUNT(*) FROM professor WHERE PROF_Email = @Email AND PROF_Senha = @Senha";
                    using (MySqlCommand cmd = new MySqlCommand(queryProfessor, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Senha", senha);
                        int professorCount = Convert.ToInt32(cmd.ExecuteScalar());

                        if (professorCount > 0)
                        {
                            UsuarioSession.ID = Convert.ToInt32(professorCount);
                            UsuarioSession.TipoUsuario = "Professor";
                            MessageBox.Show("Login como professor bem-sucedido!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Menu_Prof painelProfessor = new Menu_Prof();
                            painelProfessor.Show();
                            this.Hide();
                            return;
                        }
                    }

                    // Se não encontrou nenhum usuário
                    MessageBox.Show("Email ou senha incorretos. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            // Se o cadastro não foi encontrado em professores, tenta verificar na tabela de alunos
            using (MySqlConnection conexao = new MySqlConnection("Server=127.0.0.1;Port=3306;Database=watertrack;User=root;Password="))
            {
                try
                {
                    conexao.Open();

                    // Query para verificar o aluno
                    string queryAluno = "SELECT COUNT(*) FROM aluno WHERE ALU_Email = @Email AND ALU_Senha = @Senha";

                    using (MySqlCommand cmd = new MySqlCommand(queryAluno, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Senha", senha);

                        int alunoCount = Convert.ToInt32(cmd.ExecuteScalar());

                        // Se o aluno foi encontrado, loga e finaliza o método
                        if (alunoCount > 0)
                        {
                            MessageBox.Show("Login como aluno bem-sucedido!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Armazena as informações na UsuarioSession
                            //SessãoUsuario.UsuarioEmail = email;
                            //SessãoUsuario.TipoUsuario = "aluno";

                            // Abrir janela principal de aluno
                            Menu_Alun painelAluno = new Menu_Alun();
                            painelAluno.Show();
                            this.Hide(); // Esconde a janela de login
                        }
                        else
                        {
                            // Se nenhum usuário foi encontrado em funcionários ou alunos
                            MessageBox.Show("Email ou senha incorretos. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void labelEsqueci_MouseEnter(object sender, EventArgs e)
        {
            labelEsqueci.Cursor = Cursors.Hand;
        }

        private void labelEsqueci_MouseLeave(object sender, EventArgs e)
        {
            labelEsqueci.Cursor = Cursors.Default;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void painelLogin_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}