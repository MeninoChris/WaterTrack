﻿namespace WaterTrack
{
    partial class Cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cadastro));
            this.painelDireito = new System.Windows.Forms.Panel();
            this.mostrar_Hind2 = new System.Windows.Forms.PictureBox();
            this.mostrar_Hind1 = new System.Windows.Forms.PictureBox();
            this.caixaConfSenha = new System.Windows.Forms.MaskedTextBox();
            this.caixaSenha = new System.Windows.Forms.MaskedTextBox();
            this.caixaCel = new System.Windows.Forms.MaskedTextBox();
            this.caixaNascimento = new System.Windows.Forms.DateTimePicker();
            this.labelLogin = new System.Windows.Forms.Label();
            this.labelOpa = new System.Windows.Forms.Label();
            this.labelSair = new System.Windows.Forms.Label();
            this.botaoCadastrar = new System.Windows.Forms.Button();
            this.labelConfsenha = new System.Windows.Forms.Label();
            this.labelSenha = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelCel = new System.Windows.Forms.Label();
            this.labelNascimento = new System.Windows.Forms.Label();
            this.caixaEmail = new System.Windows.Forms.TextBox();
            this.caixaNome = new System.Windows.Forms.TextBox();
            this.labelNome = new System.Windows.Forms.Label();
            this.labelCadastro = new System.Windows.Forms.Label();
            this.painelEsqurdo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkAluno = new System.Windows.Forms.CheckBox();
            this.checkProfessor = new System.Windows.Forms.CheckBox();
            this.labelEscola = new System.Windows.Forms.Label();
            this.caixaEscola = new System.Windows.Forms.TextBox();
            this.painelDireito.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mostrar_Hind2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mostrar_Hind1)).BeginInit();
            this.painelEsqurdo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // painelDireito
            // 
            this.painelDireito.BackColor = System.Drawing.Color.Transparent;
            this.painelDireito.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.painelDireito.Controls.Add(this.checkProfessor);
            this.painelDireito.Controls.Add(this.checkAluno);
            this.painelDireito.Controls.Add(this.mostrar_Hind2);
            this.painelDireito.Controls.Add(this.mostrar_Hind1);
            this.painelDireito.Controls.Add(this.caixaConfSenha);
            this.painelDireito.Controls.Add(this.caixaSenha);
            this.painelDireito.Controls.Add(this.caixaCel);
            this.painelDireito.Controls.Add(this.caixaNascimento);
            this.painelDireito.Controls.Add(this.labelLogin);
            this.painelDireito.Controls.Add(this.labelOpa);
            this.painelDireito.Controls.Add(this.labelSair);
            this.painelDireito.Controls.Add(this.botaoCadastrar);
            this.painelDireito.Controls.Add(this.labelConfsenha);
            this.painelDireito.Controls.Add(this.labelSenha);
            this.painelDireito.Controls.Add(this.labelEscola);
            this.painelDireito.Controls.Add(this.labelEmail);
            this.painelDireito.Controls.Add(this.labelCel);
            this.painelDireito.Controls.Add(this.labelNascimento);
            this.painelDireito.Controls.Add(this.caixaEmail);
            this.painelDireito.Controls.Add(this.caixaEscola);
            this.painelDireito.Controls.Add(this.caixaNome);
            this.painelDireito.Controls.Add(this.labelNome);
            this.painelDireito.Controls.Add(this.labelCadastro);
            this.painelDireito.Dock = System.Windows.Forms.DockStyle.Right;
            this.painelDireito.Location = new System.Drawing.Point(329, 0);
            this.painelDireito.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.painelDireito.Name = "painelDireito";
            this.painelDireito.Size = new System.Drawing.Size(421, 450);
            this.painelDireito.TabIndex = 0;
            this.painelDireito.Paint += new System.Windows.Forms.PaintEventHandler(this.painelDireito_Paint);
            // 
            // mostrar_Hind2
            // 
            this.mostrar_Hind2.Location = new System.Drawing.Point(377, 316);
            this.mostrar_Hind2.Name = "mostrar_Hind2";
            this.mostrar_Hind2.Size = new System.Drawing.Size(28, 22);
            this.mostrar_Hind2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mostrar_Hind2.TabIndex = 14;
            this.mostrar_Hind2.TabStop = false;
            this.mostrar_Hind2.Click += new System.EventHandler(this.mostrar_Hind2_Click);
            this.mostrar_Hind2.MouseEnter += new System.EventHandler(this.mostrar_Hind2_MouseEnter);
            this.mostrar_Hind2.MouseLeave += new System.EventHandler(this.mostrar_Hind2_MouseLeave);
            // 
            // mostrar_Hind1
            // 
            this.mostrar_Hind1.Location = new System.Drawing.Point(162, 316);
            this.mostrar_Hind1.Name = "mostrar_Hind1";
            this.mostrar_Hind1.Size = new System.Drawing.Size(28, 22);
            this.mostrar_Hind1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mostrar_Hind1.TabIndex = 13;
            this.mostrar_Hind1.TabStop = false;
            this.mostrar_Hind1.Click += new System.EventHandler(this.mostrar_Hind_Click);
            this.mostrar_Hind1.MouseEnter += new System.EventHandler(this.mostrar_Hind1_MouseEnter);
            this.mostrar_Hind1.MouseLeave += new System.EventHandler(this.mostrar_Hind1_MouseLeave);
            // 
            // caixaConfSenha
            // 
            this.caixaConfSenha.Location = new System.Drawing.Point(214, 315);
            this.caixaConfSenha.Name = "caixaConfSenha";
            this.caixaConfSenha.PasswordChar = '*';
            this.caixaConfSenha.Size = new System.Drawing.Size(152, 20);
            this.caixaConfSenha.TabIndex = 6;
            // 
            // caixaSenha
            // 
            this.caixaSenha.Location = new System.Drawing.Point(22, 316);
            this.caixaSenha.Name = "caixaSenha";
            this.caixaSenha.PasswordChar = '*';
            this.caixaSenha.Size = new System.Drawing.Size(134, 20);
            this.caixaSenha.TabIndex = 5;
            // 
            // caixaCel
            // 
            this.caixaCel.Location = new System.Drawing.Point(237, 216);
            this.caixaCel.Mask = "(00) 00000-0000";
            this.caixaCel.Name = "caixaCel";
            this.caixaCel.Size = new System.Drawing.Size(152, 20);
            this.caixaCel.TabIndex = 3;
            // 
            // caixaNascimento
            // 
            this.caixaNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.caixaNascimento.Location = new System.Drawing.Point(24, 216);
            this.caixaNascimento.MaxDate = new System.DateTime(2025, 12, 31, 0, 0, 0, 0);
            this.caixaNascimento.MinDate = new System.DateTime(1945, 1, 1, 0, 0, 0, 0);
            this.caixaNascimento.Name = "caixaNascimento";
            this.caixaNascimento.Size = new System.Drawing.Size(200, 20);
            this.caixaNascimento.TabIndex = 2;
            this.caixaNascimento.Tag = "";
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.BackColor = System.Drawing.Color.Transparent;
            this.labelLogin.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogin.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labelLogin.Location = new System.Drawing.Point(167, 390);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(91, 16);
            this.labelLogin.TabIndex = 8;
            this.labelLogin.Text = "Faça o Login";
            this.labelLogin.Click += new System.EventHandler(this.labelLogin_Click);
            this.labelLogin.MouseEnter += new System.EventHandler(this.labelLogin_MouseEnter);
            this.labelLogin.MouseLeave += new System.EventHandler(this.labelLogin_MouseLeave);
            // 
            // labelOpa
            // 
            this.labelOpa.AutoSize = true;
            this.labelOpa.BackColor = System.Drawing.Color.Transparent;
            this.labelOpa.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOpa.Location = new System.Drawing.Point(21, 390);
            this.labelOpa.Name = "labelOpa";
            this.labelOpa.Size = new System.Drawing.Size(140, 16);
            this.labelOpa.TabIndex = 12;
            this.labelOpa.Text = "Opa! Tem uma conta?";
            // 
            // labelSair
            // 
            this.labelSair.AutoSize = true;
            this.labelSair.BackColor = System.Drawing.Color.Transparent;
            this.labelSair.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSair.Location = new System.Drawing.Point(359, 420);
            this.labelSair.Name = "labelSair";
            this.labelSair.Size = new System.Drawing.Size(35, 16);
            this.labelSair.TabIndex = 9;
            this.labelSair.Text = "SAIR";
            this.labelSair.Click += new System.EventHandler(this.labelSair_Click);
            this.labelSair.MouseEnter += new System.EventHandler(this.labelSair_MouseEnter);
            this.labelSair.MouseLeave += new System.EventHandler(this.labelSair_MouseLeave);
            // 
            // botaoCadastrar
            // 
            this.botaoCadastrar.BackColor = System.Drawing.Color.LightBlue;
            this.botaoCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botaoCadastrar.Font = new System.Drawing.Font("JetBrains Mono", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botaoCadastrar.Location = new System.Drawing.Point(22, 354);
            this.botaoCadastrar.Name = "botaoCadastrar";
            this.botaoCadastrar.Size = new System.Drawing.Size(367, 33);
            this.botaoCadastrar.TabIndex = 7;
            this.botaoCadastrar.Text = "Cadastrar";
            this.botaoCadastrar.UseVisualStyleBackColor = false;
            this.botaoCadastrar.Click += new System.EventHandler(this.botaoCadastrar_Click);
            this.botaoCadastrar.MouseEnter += new System.EventHandler(this.botaoCadastrar_MouseEnter);
            this.botaoCadastrar.MouseLeave += new System.EventHandler(this.botaoCadastrar_MouseLeave);
            // 
            // labelConfsenha
            // 
            this.labelConfsenha.AutoSize = true;
            this.labelConfsenha.BackColor = System.Drawing.Color.Transparent;
            this.labelConfsenha.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConfsenha.Location = new System.Drawing.Point(211, 295);
            this.labelConfsenha.Name = "labelConfsenha";
            this.labelConfsenha.Size = new System.Drawing.Size(119, 16);
            this.labelConfsenha.TabIndex = 8;
            this.labelConfsenha.Text = "Confirmar Senha:";
            // 
            // labelSenha
            // 
            this.labelSenha.AutoSize = true;
            this.labelSenha.BackColor = System.Drawing.Color.Transparent;
            this.labelSenha.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSenha.Location = new System.Drawing.Point(21, 295);
            this.labelSenha.Name = "labelSenha";
            this.labelSenha.Size = new System.Drawing.Size(49, 16);
            this.labelSenha.TabIndex = 7;
            this.labelSenha.Text = "Senha:";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.BackColor = System.Drawing.Color.Transparent;
            this.labelEmail.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(21, 241);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(49, 16);
            this.labelEmail.TabIndex = 6;
            this.labelEmail.Text = "Email:";
            // 
            // labelCel
            // 
            this.labelCel.AutoSize = true;
            this.labelCel.BackColor = System.Drawing.Color.Transparent;
            this.labelCel.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCel.Location = new System.Drawing.Point(234, 196);
            this.labelCel.Name = "labelCel";
            this.labelCel.Size = new System.Drawing.Size(91, 16);
            this.labelCel.TabIndex = 5;
            this.labelCel.Text = "Celular/Tel:";
            // 
            // labelNascimento
            // 
            this.labelNascimento.AutoSize = true;
            this.labelNascimento.BackColor = System.Drawing.Color.Transparent;
            this.labelNascimento.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNascimento.Location = new System.Drawing.Point(19, 196);
            this.labelNascimento.Name = "labelNascimento";
            this.labelNascimento.Size = new System.Drawing.Size(140, 16);
            this.labelNascimento.TabIndex = 4;
            this.labelNascimento.Text = "Data de Nascimento:";
            // 
            // caixaEmail
            // 
            this.caixaEmail.Location = new System.Drawing.Point(22, 261);
            this.caixaEmail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaEmail.Name = "caixaEmail";
            this.caixaEmail.Size = new System.Drawing.Size(367, 20);
            this.caixaEmail.TabIndex = 4;
            // 
            // caixaNome
            // 
            this.caixaNome.Location = new System.Drawing.Point(23, 136);
            this.caixaNome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaNome.Name = "caixaNome";
            this.caixaNome.Size = new System.Drawing.Size(343, 20);
            this.caixaNome.TabIndex = 0;
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.BackColor = System.Drawing.Color.Transparent;
            this.labelNome.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNome.Location = new System.Drawing.Point(21, 116);
            this.labelNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(105, 16);
            this.labelNome.TabIndex = 1;
            this.labelNome.Text = "Nome completo:";
            // 
            // labelCadastro
            // 
            this.labelCadastro.AutoSize = true;
            this.labelCadastro.BackColor = System.Drawing.Color.Transparent;
            this.labelCadastro.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 40F);
            this.labelCadastro.Location = new System.Drawing.Point(130, 52);
            this.labelCadastro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCadastro.Name = "labelCadastro";
            this.labelCadastro.Size = new System.Drawing.Size(161, 63);
            this.labelCadastro.TabIndex = 0;
            this.labelCadastro.Text = "Cadastro";
            // 
            // painelEsqurdo
            // 
            this.painelEsqurdo.Controls.Add(this.pictureBox1);
            this.painelEsqurdo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.painelEsqurdo.Location = new System.Drawing.Point(0, 0);
            this.painelEsqurdo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.painelEsqurdo.Name = "painelEsqurdo";
            this.painelEsqurdo.Size = new System.Drawing.Size(329, 450);
            this.painelEsqurdo.TabIndex = 1;
            this.painelEsqurdo.Paint += new System.Windows.Forms.PaintEventHandler(this.painelEsqurdo_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(329, 450);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // checkAluno
            // 
            this.checkAluno.AutoSize = true;
            this.checkAluno.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkAluno.Location = new System.Drawing.Point(24, 162);
            this.checkAluno.Name = "checkAluno";
            this.checkAluno.Size = new System.Drawing.Size(61, 20);
            this.checkAluno.TabIndex = 15;
            this.checkAluno.Text = "Aluno";
            this.checkAluno.UseVisualStyleBackColor = true;
            // 
            // checkProfessor
            // 
            this.checkProfessor.AutoSize = true;
            this.checkProfessor.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkProfessor.Location = new System.Drawing.Point(83, 162);
            this.checkProfessor.Name = "checkProfessor";
            this.checkProfessor.Size = new System.Drawing.Size(89, 20);
            this.checkProfessor.TabIndex = 16;
            this.checkProfessor.Text = "Professor";
            this.checkProfessor.UseVisualStyleBackColor = true;
            // 
            // labelEscola
            // 
            this.labelEscola.AutoSize = true;
            this.labelEscola.BackColor = System.Drawing.Color.Transparent;
            this.labelEscola.Font = new System.Drawing.Font("JetBrains Mono", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEscola.Location = new System.Drawing.Point(178, 163);
            this.labelEscola.Name = "labelEscola";
            this.labelEscola.Size = new System.Drawing.Size(56, 16);
            this.labelEscola.TabIndex = 5;
            this.labelEscola.Text = "Escola:";
            // 
            // caixaEscola
            // 
            this.caixaEscola.Location = new System.Drawing.Point(237, 161);
            this.caixaEscola.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaEscola.Name = "caixaEscola";
            this.caixaEscola.Size = new System.Drawing.Size(128, 20);
            this.caixaEscola.TabIndex = 0;
            // 
            // Cadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(750, 450);
            this.Controls.Add(this.painelEsqurdo);
            this.Controls.Add(this.painelDireito);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximumSize = new System.Drawing.Size(750, 450);
            this.MinimumSize = new System.Drawing.Size(750, 450);
            this.Name = "Cadastro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro";
            this.painelDireito.ResumeLayout(false);
            this.painelDireito.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mostrar_Hind2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mostrar_Hind1)).EndInit();
            this.painelEsqurdo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel painelDireito;
        private System.Windows.Forms.Label labelCadastro;
        private System.Windows.Forms.Panel painelEsqurdo;
        private System.Windows.Forms.TextBox caixaNome;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelCel;
        private System.Windows.Forms.Label labelNascimento;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox caixaEmail;
        private System.Windows.Forms.Label labelConfsenha;
        private System.Windows.Forms.Label labelSenha;
        private System.Windows.Forms.Button botaoCadastrar;
        private System.Windows.Forms.Label labelSair;
        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.Label labelOpa;
        private System.Windows.Forms.DateTimePicker caixaNascimento;
        private System.Windows.Forms.MaskedTextBox caixaCel;
        private System.Windows.Forms.PictureBox mostrar_Hind1;
        private System.Windows.Forms.PictureBox mostrar_Hind2;
        private System.Windows.Forms.MaskedTextBox caixaConfSenha;
        private System.Windows.Forms.MaskedTextBox caixaSenha;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkProfessor;
        private System.Windows.Forms.CheckBox checkAluno;
        private System.Windows.Forms.Label labelEscola;
        private System.Windows.Forms.TextBox caixaEscola;
    }
}