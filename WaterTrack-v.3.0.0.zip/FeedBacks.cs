﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection.Emit;
using System.Text;
using System.Windows.Forms;

namespace WaterTrack.Resources
{
    public partial class FeedBacks : Form
    {
        public FeedBacks()
        {
            InitializeComponent();
        }
        private void GerarFeedbacks()
        {
            // Lista de feedbacks
            List<string> feedbacks = new List<string>()
        {
            "João Silva: A interface da aplicação é incrível! Muito fácil de navegar e super intuitiva.",
            "Ana Pereira: Estou impressionada com a precisão das informações sobre o monitoramento da água.",
            "Carlos Souza: Aplicação muito funcional e prática.",
            "Mariana Oliveira: O design está impecável! Muito agradável de usar.",
            "Lucas Almeida: A apresentação dos dados facilita muito a nossa análise.",
            "Fernanda Santos: Simplesmente fantástico! Muito útil no monitoramento.",
            "Rafael Costa: A transição entre as telas é suave e organizada.",
            "Beatriz Martins: As notificações de mudanças no sistema são essenciais.",
            "Ricardo Lima: A função de feedback facilita o reporte de problemas.",
            "Juliana Ribeiro: Os dados são claros e fáceis de entender."
        };

            // Embaralha a lista de feedbacks
            Random random = new Random();
            List<string> feedbacksAleatorios = new List<string>();

            // Pega três feedbacks aleatórios da lista
            for (int i = 0; i < 3; i++)
            {
                int indexAleatorio = random.Next(feedbacks.Count);
                feedbacksAleatorios.Add(feedbacks[indexAleatorio]);
                feedbacks.RemoveAt(indexAleatorio); // Remove o feedback já utilizado
            }

            // Exibe os feedbacks nas labels
            autor1.Text = feedbacksAleatorios[0].Split(':')[0]; // Assunto do primeiro feedback
            feedback1.Text = feedbacksAleatorios[0].Split(':')[1]; // Autor do primeiro feedback

            autor2.Text = feedbacksAleatorios[1].Split(':')[0]; // Assunto do segundo feedback
            feedback2.Text = feedbacksAleatorios[1].Split(':')[1]; // Autor do segundo feedback

            autor3.Text = feedbacksAleatorios[2].Split(':')[0]; // Assunto do terceiro feedback
            feedback3.Text = feedbacksAleatorios[2].Split(':')[1]; // Autor do terceiro feedback
        }

        private void labelSair_Click(object sender, EventArgs e)
        {

            this.Hide();

        }

        private void FeedBacks_Load(object sender, EventArgs e)
        {
            GerarFeedbacks();
        }
    }
}
