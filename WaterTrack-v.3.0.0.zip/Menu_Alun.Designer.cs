﻿namespace WaterTrack
{
    partial class Menu_Alun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu_Alun));
            this.painelTitulo = new System.Windows.Forms.Panel();
            this.labelTitulo = new System.Windows.Forms.Label();
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.ContaMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AlterarDadosMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AlterarSenhaMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.FazerLogoutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfiguraçõesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.SuporteMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.labelVersão = new System.Windows.Forms.Label();
            this.botãoÁgua = new System.Windows.Forms.Button();
            this.botãoProblema = new System.Windows.Forms.Button();
            this.botãoRecomendação = new System.Windows.Forms.Button();
            this.botãoSobre = new System.Windows.Forms.Button();
            this.PainelLayout = new System.Windows.Forms.FlowLayoutPanel();
            this.painelTitulo.SuspendLayout();
            this.Menu.SuspendLayout();
            this.PainelLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // painelTitulo
            // 
            this.painelTitulo.BackColor = System.Drawing.Color.Transparent;
            this.painelTitulo.Controls.Add(this.labelTitulo);
            this.painelTitulo.Location = new System.Drawing.Point(274, 27);
            this.painelTitulo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.painelTitulo.Name = "painelTitulo";
            this.painelTitulo.Size = new System.Drawing.Size(476, 84);
            this.painelTitulo.TabIndex = 0;
            // 
            // labelTitulo
            // 
            this.labelTitulo.AutoSize = true;
            this.labelTitulo.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitulo.Location = new System.Drawing.Point(20, 15);
            this.labelTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTitulo.Name = "labelTitulo";
            this.labelTitulo.Size = new System.Drawing.Size(436, 61);
            this.labelTitulo.TabIndex = 2;
            this.labelTitulo.Text = "Bem Vindo ao Water Track!";
            // 
            // Menu
            // 
            this.Menu.BackColor = System.Drawing.Color.Transparent;
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ContaMenu,
            this.ConfiguraçõesMenu,
            this.SuporteMenu});
            this.Menu.Location = new System.Drawing.Point(0, 0);
            this.Menu.Name = "Menu";
            this.Menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.Menu.Size = new System.Drawing.Size(750, 29);
            this.Menu.TabIndex = 2;
            this.Menu.Text = "menuStrip1";
            // 
            // ContaMenu
            // 
            this.ContaMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AlterarDadosMenu,
            this.AlterarSenhaMenu,
            this.FazerLogoutMenu});
            this.ContaMenu.Font = new System.Drawing.Font("JetBrains Mono", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContaMenu.Name = "ContaMenu";
            this.ContaMenu.Size = new System.Drawing.Size(72, 25);
            this.ContaMenu.Text = "Conta";
            // 
            // AlterarDadosMenu
            // 
            this.AlterarDadosMenu.Name = "AlterarDadosMenu";
            this.AlterarDadosMenu.Size = new System.Drawing.Size(210, 26);
            this.AlterarDadosMenu.Text = "Alterar Dados";
            this.AlterarDadosMenu.Click += new System.EventHandler(this.AlterarDadosMenu_Click);
            // 
            // AlterarSenhaMenu
            // 
            this.AlterarSenhaMenu.Name = "AlterarSenhaMenu";
            this.AlterarSenhaMenu.Size = new System.Drawing.Size(210, 26);
            this.AlterarSenhaMenu.Text = "Alterar Senha";
            this.AlterarSenhaMenu.Click += new System.EventHandler(this.AlterarSenhaMenu_Click);
            // 
            // FazerLogoutMenu
            // 
            this.FazerLogoutMenu.Name = "FazerLogoutMenu";
            this.FazerLogoutMenu.Size = new System.Drawing.Size(210, 26);
            this.FazerLogoutMenu.Text = "Fazer Logout";
            this.FazerLogoutMenu.Click += new System.EventHandler(this.FazerLogoutMenu_Click);
            // 
            // ConfiguraçõesMenu
            // 
            this.ConfiguraçõesMenu.Font = new System.Drawing.Font("JetBrains Mono", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfiguraçõesMenu.Name = "ConfiguraçõesMenu";
            this.ConfiguraçõesMenu.Size = new System.Drawing.Size(152, 25);
            this.ConfiguraçõesMenu.Text = "Configurações";
            // 
            // SuporteMenu
            // 
            this.SuporteMenu.Font = new System.Drawing.Font("JetBrains Mono", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SuporteMenu.Name = "SuporteMenu";
            this.SuporteMenu.Size = new System.Drawing.Size(92, 25);
            this.SuporteMenu.Text = "Suporte";
            // 
            // labelVersão
            // 
            this.labelVersão.AutoSize = true;
            this.labelVersão.BackColor = System.Drawing.Color.Transparent;
            this.labelVersão.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVersão.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.labelVersão.Location = new System.Drawing.Point(605, 435);
            this.labelVersão.Margin = new System.Windows.Forms.Padding(3);
            this.labelVersão.Name = "labelVersão";
            this.labelVersão.Size = new System.Drawing.Size(57, 13);
            this.labelVersão.TabIndex = 3;
            this.labelVersão.Text = "VERSÃO";
            // 
            // botãoÁgua
            // 
            this.botãoÁgua.BackColor = System.Drawing.Color.LightBlue;
            this.botãoÁgua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoÁgua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoÁgua.Image = ((System.Drawing.Image)(resources.GetObject("botãoÁgua.Image")));
            this.botãoÁgua.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.botãoÁgua.Location = new System.Drawing.Point(3, 4);
            this.botãoÁgua.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.botãoÁgua.Name = "botãoÁgua";
            this.botãoÁgua.Size = new System.Drawing.Size(264, 99);
            this.botãoÁgua.TabIndex = 0;
            this.botãoÁgua.Text = "Sobre a Água";
            this.botãoÁgua.UseVisualStyleBackColor = false;
            this.botãoÁgua.Click += new System.EventHandler(this.botãoÁgua_Click);
            // 
            // botãoProblema
            // 
            this.botãoProblema.BackColor = System.Drawing.Color.LightBlue;
            this.botãoProblema.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoProblema.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoProblema.Image = ((System.Drawing.Image)(resources.GetObject("botãoProblema.Image")));
            this.botãoProblema.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.botãoProblema.Location = new System.Drawing.Point(3, 110);
            this.botãoProblema.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.botãoProblema.Name = "botãoProblema";
            this.botãoProblema.Size = new System.Drawing.Size(264, 99);
            this.botãoProblema.TabIndex = 1;
            this.botãoProblema.Text = "Reportar Problema";
            this.botãoProblema.UseVisualStyleBackColor = false;
            this.botãoProblema.Click += new System.EventHandler(this.botãoProblema_Click);
            // 
            // botãoRecomendação
            // 
            this.botãoRecomendação.BackColor = System.Drawing.Color.LightBlue;
            this.botãoRecomendação.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoRecomendação.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoRecomendação.Image = ((System.Drawing.Image)(resources.GetObject("botãoRecomendação.Image")));
            this.botãoRecomendação.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.botãoRecomendação.Location = new System.Drawing.Point(3, 216);
            this.botãoRecomendação.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.botãoRecomendação.Name = "botãoRecomendação";
            this.botãoRecomendação.Size = new System.Drawing.Size(264, 99);
            this.botãoRecomendação.TabIndex = 2;
            this.botãoRecomendação.Text = "Recomendação \r\nou Comentarios";
            this.botãoRecomendação.UseVisualStyleBackColor = false;
            this.botãoRecomendação.Click += new System.EventHandler(this.botãoRecomendação_Click);
            // 
            // botãoSobre
            // 
            this.botãoSobre.BackColor = System.Drawing.Color.LightBlue;
            this.botãoSobre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoSobre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoSobre.Image = ((System.Drawing.Image)(resources.GetObject("botãoSobre.Image")));
            this.botãoSobre.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.botãoSobre.Location = new System.Drawing.Point(3, 322);
            this.botãoSobre.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.botãoSobre.Name = "botãoSobre";
            this.botãoSobre.Size = new System.Drawing.Size(264, 99);
            this.botãoSobre.TabIndex = 3;
            this.botãoSobre.Text = "Conheça Sobre Nos!";
            this.botãoSobre.UseVisualStyleBackColor = false;
            this.botãoSobre.Click += new System.EventHandler(this.botãoSobre_Click);
            // 
            // PainelLayout
            // 
            this.PainelLayout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PainelLayout.Controls.Add(this.botãoÁgua);
            this.PainelLayout.Controls.Add(this.botãoProblema);
            this.PainelLayout.Controls.Add(this.botãoRecomendação);
            this.PainelLayout.Controls.Add(this.botãoSobre);
            this.PainelLayout.Location = new System.Drawing.Point(0, 27);
            this.PainelLayout.Margin = new System.Windows.Forms.Padding(0);
            this.PainelLayout.Name = "PainelLayout";
            this.PainelLayout.Size = new System.Drawing.Size(272, 423);
            this.PainelLayout.TabIndex = 4;
            // 
            // Menu_Alun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(750, 450);
            this.Controls.Add(this.PainelLayout);
            this.Controls.Add(this.labelVersão);
            this.Controls.Add(this.painelTitulo);
            this.Controls.Add(this.Menu);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.Menu;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(750, 450);
            this.MinimizeBox = false;
            this.Name = "Menu_Alun";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bem Vindo";
            this.painelTitulo.ResumeLayout(false);
            this.painelTitulo.PerformLayout();
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            this.PainelLayout.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel painelTitulo;
        private System.Windows.Forms.Label labelTitulo;
        private System.Windows.Forms.MenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem ContaMenu;
        private System.Windows.Forms.ToolStripMenuItem ConfiguraçõesMenu;
        private System.Windows.Forms.ToolStripMenuItem SuporteMenu;
        private System.Windows.Forms.ToolStripMenuItem AlterarDadosMenu;
        private System.Windows.Forms.ToolStripMenuItem AlterarSenhaMenu;
        private System.Windows.Forms.Label labelVersão;
        private System.Windows.Forms.Button botãoSobre;
        private System.Windows.Forms.Button botãoRecomendação;
        private System.Windows.Forms.Button botãoProblema;
        private System.Windows.Forms.Button botãoÁgua;
        private System.Windows.Forms.FlowLayoutPanel PainelLayout;
        private System.Windows.Forms.ToolStripMenuItem FazerLogoutMenu;
    }
}