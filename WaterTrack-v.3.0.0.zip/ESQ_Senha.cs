﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WaterTrack
{
    public partial class ESQ_Senha : Form
    {
        public ESQ_Senha()
        {
            InitializeComponent();
        }
        int vCode = 1000;

        private void timeVCODE_Tick(object sender, EventArgs e)
        {
            vCode += 10;
            if (vCode == 9999)
            {
                vCode = 1000;

            }
        }

        private void botãoEnviar_Click(object sender, EventArgs e)
        {
            timeVCODE.Stop();
            string to, from, pass, mail;
            to = caixaEmail.Text;
            from = "nexgensolutionscf@gmail.com";
            mail = vCode.ToString();
            pass = "s j w e s o y v l w f l v l j m\r\n";
            MailMessage message = new MailMessage();
            message.To.Add(to);
            message.From = new MailAddress(from);
            message.Body = mail;
            message.Subject = "Aqui está seu codigo de verificação - Codigo de Verificação";
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.EnableSsl = true;
            smtp.Port = 587;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(from, pass);
            try
            {
                smtp.Send(message);
                MessageBox.Show("Codigo de Verificação enviado com Sucesso", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                caixaCodigo.Enabled = true;
                botãoConfirmar.Enabled = true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void botãoConfirmar_Click(object sender, EventArgs e)
        {
            if (caixaCodigo.Text == vCode.ToString())
            {
                ESQ_MinhaSenha main = new ESQ_MinhaSenha();
                main.Show();
            }
        }
    }
}
