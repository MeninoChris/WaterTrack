﻿namespace WaterTrack
{
    partial class Menu_Prof
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu_Prof));
            this.painelTitulo = new System.Windows.Forms.Panel();
            this.labelTitulo = new System.Windows.Forms.Label();
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.ContaMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AlterarDadosMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.AlterarSenhaMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.FazerLogoutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ConfiguraçõesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.SuporteMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.contatarFornecedorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.funçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alertasAvisosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerarRelatorioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PainelLayout = new System.Windows.Forms.FlowLayoutPanel();
            this.botãoÁgua = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.botãoProblema = new System.Windows.Forms.Button();
            this.botãoSobre = new System.Windows.Forms.Button();
            this.labelVersão = new System.Windows.Forms.Label();
            this.labelSair = new System.Windows.Forms.Label();
            this.painelTitulo.SuspendLayout();
            this.Menu.SuspendLayout();
            this.PainelLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // painelTitulo
            // 
            this.painelTitulo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.painelTitulo.BackColor = System.Drawing.Color.Transparent;
            this.painelTitulo.Controls.Add(this.labelTitulo);
            this.painelTitulo.Location = new System.Drawing.Point(274, 27);
            this.painelTitulo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.painelTitulo.Name = "painelTitulo";
            this.painelTitulo.Size = new System.Drawing.Size(476, 84);
            this.painelTitulo.TabIndex = 5;
            // 
            // labelTitulo
            // 
            this.labelTitulo.AutoSize = true;
            this.labelTitulo.BackColor = System.Drawing.Color.Transparent;
            this.labelTitulo.Font = new System.Drawing.Font("Gloucester MT Extra Condensed", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitulo.ForeColor = System.Drawing.Color.Black;
            this.labelTitulo.Location = new System.Drawing.Point(20, 12);
            this.labelTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTitulo.Name = "labelTitulo";
            this.labelTitulo.Size = new System.Drawing.Size(436, 61);
            this.labelTitulo.TabIndex = 2;
            this.labelTitulo.Text = "Bem Vindo ao Water Track!";
            // 
            // Menu
            // 
            this.Menu.BackColor = System.Drawing.Color.Transparent;
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ContaMenu,
            this.ConfiguraçõesMenu,
            this.SuporteMenu,
            this.funçõesToolStripMenuItem});
            this.Menu.Location = new System.Drawing.Point(0, 0);
            this.Menu.Name = "Menu";
            this.Menu.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.Menu.Size = new System.Drawing.Size(750, 28);
            this.Menu.TabIndex = 6;
            this.Menu.Text = "menuStrip1";
            // 
            // ContaMenu
            // 
            this.ContaMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AlterarDadosMenu,
            this.AlterarSenhaMenu,
            this.FazerLogoutMenu});
            this.ContaMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContaMenu.Name = "ContaMenu";
            this.ContaMenu.Size = new System.Drawing.Size(69, 24);
            this.ContaMenu.Text = "Conta";
            // 
            // AlterarDadosMenu
            // 
            this.AlterarDadosMenu.Name = "AlterarDadosMenu";
            this.AlterarDadosMenu.Size = new System.Drawing.Size(189, 24);
            this.AlterarDadosMenu.Text = "Alterar Dados";
            this.AlterarDadosMenu.Click += new System.EventHandler(this.AlterarDadosMenu_Click);
            // 
            // AlterarSenhaMenu
            // 
            this.AlterarSenhaMenu.Name = "AlterarSenhaMenu";
            this.AlterarSenhaMenu.Size = new System.Drawing.Size(189, 24);
            this.AlterarSenhaMenu.Text = "Alterar Senha";
            this.AlterarSenhaMenu.Click += new System.EventHandler(this.AlterarSenhaMenu_Click);
            // 
            // FazerLogoutMenu
            // 
            this.FazerLogoutMenu.Name = "FazerLogoutMenu";
            this.FazerLogoutMenu.Size = new System.Drawing.Size(189, 24);
            this.FazerLogoutMenu.Text = "Fazer Logout";
            this.FazerLogoutMenu.Click += new System.EventHandler(this.FazerLogoutMenu_Click);
            // 
            // ConfiguraçõesMenu
            // 
            this.ConfiguraçõesMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfiguraçõesMenu.Name = "ConfiguraçõesMenu";
            this.ConfiguraçõesMenu.Size = new System.Drawing.Size(137, 24);
            this.ConfiguraçõesMenu.Text = "Configurações";
            this.ConfiguraçõesMenu.Click += new System.EventHandler(this.ConfiguraçõesMenu_Click);
            // 
            // SuporteMenu
            // 
            this.SuporteMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contatarFornecedorToolStripMenuItem1});
            this.SuporteMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SuporteMenu.Name = "SuporteMenu";
            this.SuporteMenu.Size = new System.Drawing.Size(85, 24);
            this.SuporteMenu.Text = "Suporte";
            // 
            // contatarFornecedorToolStripMenuItem1
            // 
            this.contatarFornecedorToolStripMenuItem1.Name = "contatarFornecedorToolStripMenuItem1";
            this.contatarFornecedorToolStripMenuItem1.Size = new System.Drawing.Size(240, 24);
            this.contatarFornecedorToolStripMenuItem1.Text = "Contatar fornecedor";
            this.contatarFornecedorToolStripMenuItem1.Click += new System.EventHandler(this.contatarFornecedorToolStripMenuItem1_Click);
            // 
            // funçõesToolStripMenuItem
            // 
            this.funçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alertasAvisosToolStripMenuItem,
            this.gerarRelatorioToolStripMenuItem});
            this.funçõesToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.funçõesToolStripMenuItem.Name = "funçõesToolStripMenuItem";
            this.funçõesToolStripMenuItem.Size = new System.Drawing.Size(90, 24);
            this.funçõesToolStripMenuItem.Text = "Funções";
            // 
            // alertasAvisosToolStripMenuItem
            // 
            this.alertasAvisosToolStripMenuItem.Name = "alertasAvisosToolStripMenuItem";
            this.alertasAvisosToolStripMenuItem.Size = new System.Drawing.Size(202, 24);
            this.alertasAvisosToolStripMenuItem.Text = "Alertas/Avisos";
            this.alertasAvisosToolStripMenuItem.Click += new System.EventHandler(this.alertasAvisosToolStripMenuItem_Click);
            // 
            // gerarRelatorioToolStripMenuItem
            // 
            this.gerarRelatorioToolStripMenuItem.Name = "gerarRelatorioToolStripMenuItem";
            this.gerarRelatorioToolStripMenuItem.Size = new System.Drawing.Size(202, 24);
            this.gerarRelatorioToolStripMenuItem.Text = "Gerar Relatorio";
            this.gerarRelatorioToolStripMenuItem.Click += new System.EventHandler(this.gerarRelatorioToolStripMenuItem_Click);
            // 
            // PainelLayout
            // 
            this.PainelLayout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PainelLayout.Controls.Add(this.botãoÁgua);
            this.PainelLayout.Controls.Add(this.button1);
            this.PainelLayout.Controls.Add(this.button3);
            this.PainelLayout.Controls.Add(this.button2);
            this.PainelLayout.Controls.Add(this.botãoProblema);
            this.PainelLayout.Controls.Add(this.botãoSobre);
            this.PainelLayout.Location = new System.Drawing.Point(0, 27);
            this.PainelLayout.Margin = new System.Windows.Forms.Padding(0);
            this.PainelLayout.Name = "PainelLayout";
            this.PainelLayout.Size = new System.Drawing.Size(272, 424);
            this.PainelLayout.TabIndex = 8;
            // 
            // botãoÁgua
            // 
            this.botãoÁgua.BackColor = System.Drawing.Color.LightBlue;
            this.botãoÁgua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoÁgua.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoÁgua.ForeColor = System.Drawing.Color.Black;
            this.botãoÁgua.Image = ((System.Drawing.Image)(resources.GetObject("botãoÁgua.Image")));
            this.botãoÁgua.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.botãoÁgua.Location = new System.Drawing.Point(3, 4);
            this.botãoÁgua.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.botãoÁgua.Name = "botãoÁgua";
            this.botãoÁgua.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.botãoÁgua.Size = new System.Drawing.Size(264, 64);
            this.botãoÁgua.TabIndex = 0;
            this.botãoÁgua.Text = "Sobre a Água";
            this.botãoÁgua.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.botãoÁgua.UseVisualStyleBackColor = false;
            this.botãoÁgua.Click += new System.EventHandler(this.botãoÁgua_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightBlue;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(3, 74);
            this.button1.Name = "button1";
            this.button1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button1.Size = new System.Drawing.Size(264, 64);
            this.button1.TabIndex = 4;
            this.button1.Text = "Solicitar Manutenção";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightBlue;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.Location = new System.Drawing.Point(3, 144);
            this.button3.Name = "button3";
            this.button3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button3.Size = new System.Drawing.Size(264, 64);
            this.button3.TabIndex = 6;
            this.button3.Text = "FeedBacks";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightBlue;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.Location = new System.Drawing.Point(3, 214);
            this.button2.Name = "button2";
            this.button2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button2.Size = new System.Drawing.Size(264, 64);
            this.button2.TabIndex = 5;
            this.button2.Text = "Mapa do Sistema";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // botãoProblema
            // 
            this.botãoProblema.BackColor = System.Drawing.Color.LightBlue;
            this.botãoProblema.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoProblema.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoProblema.ForeColor = System.Drawing.Color.Black;
            this.botãoProblema.Image = ((System.Drawing.Image)(resources.GetObject("botãoProblema.Image")));
            this.botãoProblema.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.botãoProblema.Location = new System.Drawing.Point(3, 285);
            this.botãoProblema.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.botãoProblema.Name = "botãoProblema";
            this.botãoProblema.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.botãoProblema.Size = new System.Drawing.Size(264, 64);
            this.botãoProblema.TabIndex = 1;
            this.botãoProblema.Text = "Reportar Problema";
            this.botãoProblema.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.botãoProblema.UseVisualStyleBackColor = false;
            this.botãoProblema.Click += new System.EventHandler(this.botãoProblema_Click);
            // 
            // botãoSobre
            // 
            this.botãoSobre.BackColor = System.Drawing.Color.LightBlue;
            this.botãoSobre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.botãoSobre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botãoSobre.ForeColor = System.Drawing.Color.Black;
            this.botãoSobre.Image = ((System.Drawing.Image)(resources.GetObject("botãoSobre.Image")));
            this.botãoSobre.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.botãoSobre.Location = new System.Drawing.Point(3, 356);
            this.botãoSobre.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.botãoSobre.Name = "botãoSobre";
            this.botãoSobre.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.botãoSobre.Size = new System.Drawing.Size(264, 64);
            this.botãoSobre.TabIndex = 3;
            this.botãoSobre.Text = "Conheça Sobre Nos!";
            this.botãoSobre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.botãoSobre.UseVisualStyleBackColor = false;
            this.botãoSobre.Click += new System.EventHandler(this.botãoSobre_Click);
            // 
            // labelVersão
            // 
            this.labelVersão.AutoSize = true;
            this.labelVersão.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVersão.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.labelVersão.Location = new System.Drawing.Point(571, 434);
            this.labelVersão.Margin = new System.Windows.Forms.Padding(3);
            this.labelVersão.Name = "labelVersão";
            this.labelVersão.Size = new System.Drawing.Size(57, 13);
            this.labelVersão.TabIndex = 9;
            this.labelVersão.Text = "VERSÃO";
            // 
            // labelSair
            // 
            this.labelSair.AutoSize = true;
            this.labelSair.BackColor = System.Drawing.Color.Transparent;
            this.labelSair.Font = new System.Drawing.Font("JetBrains Mono", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSair.ForeColor = System.Drawing.Color.Black;
            this.labelSair.Location = new System.Drawing.Point(693, 5);
            this.labelSair.Name = "labelSair";
            this.labelSair.Size = new System.Drawing.Size(45, 19);
            this.labelSair.TabIndex = 10;
            this.labelSair.Text = "SAIR";
            this.labelSair.Click += new System.EventHandler(this.labelSair_Click);
            this.labelSair.MouseEnter += new System.EventHandler(this.labelSair_MouseEnter);
            this.labelSair.MouseLeave += new System.EventHandler(this.labelSair_MouseLeave);
            // 
            // Menu_Prof
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(750, 450);
            this.Controls.Add(this.labelSair);
            this.Controls.Add(this.painelTitulo);
            this.Controls.Add(this.labelVersão);
            this.Controls.Add(this.Menu);
            this.Controls.Add(this.PainelLayout);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.SteelBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Menu_Prof";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Menu_Func_Load);
            this.painelTitulo.ResumeLayout(false);
            this.painelTitulo.PerformLayout();
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            this.PainelLayout.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel painelTitulo;
        private System.Windows.Forms.Label labelTitulo;
        private System.Windows.Forms.MenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem ContaMenu;
        private System.Windows.Forms.ToolStripMenuItem AlterarDadosMenu;
        private System.Windows.Forms.ToolStripMenuItem AlterarSenhaMenu;
        private System.Windows.Forms.ToolStripMenuItem FazerLogoutMenu;
        private System.Windows.Forms.ToolStripMenuItem ConfiguraçõesMenu;
        private System.Windows.Forms.ToolStripMenuItem SuporteMenu;
        private System.Windows.Forms.Button botãoÁgua;
        private System.Windows.Forms.Button botãoProblema;
        private System.Windows.Forms.Button botãoSobre;
        private System.Windows.Forms.FlowLayoutPanel PainelLayout;
        private System.Windows.Forms.Label labelVersão;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem funçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alertasAvisosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerarRelatorioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contatarFornecedorToolStripMenuItem1;
        private System.Windows.Forms.Label labelSair;
    }
}