﻿namespace WaterTrack
{
    partial class AltDados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AltDados));
            this.labelID = new System.Windows.Forms.Label();
            this.caixaID = new System.Windows.Forms.TextBox();
            this.labelNome = new System.Windows.Forms.Label();
            this.caixaNome = new System.Windows.Forms.TextBox();
            this.labelDatNasci = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelCurso = new System.Windows.Forms.Label();
            this.caixaCurso = new System.Windows.Forms.TextBox();
            this.labelSobrenome = new System.Windows.Forms.Label();
            this.labelNomeESC = new System.Windows.Forms.Label();
            this.caixaEscola = new System.Windows.Forms.TextBox();
            this.botãoRemover = new System.Windows.Forms.Button();
            this.botãoFoto = new System.Windows.Forms.Button();
            this.Foto = new System.Windows.Forms.PictureBox();
            this.caixaEmail = new System.Windows.Forms.TextBox();
            this.caixaNascimento = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.caixaNumero = new System.Windows.Forms.TextBox();
            this.botãoAtualizar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Foto)).BeginInit();
            this.SuspendLayout();
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(184, 27);
            this.labelID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(21, 14);
            this.labelID.TabIndex = 0;
            this.labelID.Text = "ID";
            // 
            // caixaID
            // 
            this.caixaID.Location = new System.Drawing.Point(188, 44);
            this.caixaID.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaID.Name = "caixaID";
            this.caixaID.Size = new System.Drawing.Size(63, 22);
            this.caixaID.TabIndex = 1;
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(184, 69);
            this.labelNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(35, 14);
            this.labelNome.TabIndex = 0;
            this.labelNome.Text = "Nome";
            // 
            // caixaNome
            // 
            this.caixaNome.Location = new System.Drawing.Point(188, 86);
            this.caixaNome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaNome.Name = "caixaNome";
            this.caixaNome.Size = new System.Drawing.Size(126, 22);
            this.caixaNome.TabIndex = 1;
            // 
            // labelDatNasci
            // 
            this.labelDatNasci.AutoSize = true;
            this.labelDatNasci.Location = new System.Drawing.Point(300, 157);
            this.labelDatNasci.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDatNasci.Name = "labelDatNasci";
            this.labelDatNasci.Size = new System.Drawing.Size(133, 14);
            this.labelDatNasci.TabIndex = 0;
            this.labelDatNasci.Text = "Data de Nascimento";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(188, 111);
            this.labelEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(42, 14);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email";
            // 
            // labelCurso
            // 
            this.labelCurso.AutoSize = true;
            this.labelCurso.Location = new System.Drawing.Point(275, 27);
            this.labelCurso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCurso.Name = "labelCurso";
            this.labelCurso.Size = new System.Drawing.Size(42, 14);
            this.labelCurso.TabIndex = 0;
            this.labelCurso.Text = "Curso";
            // 
            // caixaCurso
            // 
            this.caixaCurso.Location = new System.Drawing.Point(278, 44);
            this.caixaCurso.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaCurso.Name = "caixaCurso";
            this.caixaCurso.Size = new System.Drawing.Size(170, 22);
            this.caixaCurso.TabIndex = 1;
            // 
            // labelSobrenome
            // 
            this.labelSobrenome.AutoSize = true;
            this.labelSobrenome.Location = new System.Drawing.Point(337, 69);
            this.labelSobrenome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSobrenome.Name = "labelSobrenome";
            this.labelSobrenome.Size = new System.Drawing.Size(0, 14);
            this.labelSobrenome.TabIndex = 0;
            // 
            // labelNomeESC
            // 
            this.labelNomeESC.AutoSize = true;
            this.labelNomeESC.Location = new System.Drawing.Point(184, 157);
            this.labelNomeESC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNomeESC.Name = "labelNomeESC";
            this.labelNomeESC.Size = new System.Drawing.Size(84, 14);
            this.labelNomeESC.TabIndex = 0;
            this.labelNomeESC.Text = "Nome Escola";
            // 
            // caixaEscola
            // 
            this.caixaEscola.Location = new System.Drawing.Point(188, 174);
            this.caixaEscola.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaEscola.Name = "caixaEscola";
            this.caixaEscola.Size = new System.Drawing.Size(103, 22);
            this.caixaEscola.TabIndex = 1;
            // 
            // botãoRemover
            // 
            this.botãoRemover.Image = ((System.Drawing.Image)(resources.GetObject("botãoRemover.Image")));
            this.botãoRemover.Location = new System.Drawing.Point(108, 206);
            this.botãoRemover.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.botãoRemover.Name = "botãoRemover";
            this.botãoRemover.Size = new System.Drawing.Size(69, 41);
            this.botãoRemover.TabIndex = 5;
            this.botãoRemover.UseVisualStyleBackColor = true;
            this.botãoRemover.Click += new System.EventHandler(this.botãoRemover_Click);
            // 
            // botãoFoto
            // 
            this.botãoFoto.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.botãoFoto.Image = ((System.Drawing.Image)(resources.GetObject("botãoFoto.Image")));
            this.botãoFoto.Location = new System.Drawing.Point(14, 206);
            this.botãoFoto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.botãoFoto.Name = "botãoFoto";
            this.botãoFoto.Size = new System.Drawing.Size(69, 41);
            this.botãoFoto.TabIndex = 4;
            this.botãoFoto.Text = " ";
            this.botãoFoto.UseVisualStyleBackColor = false;
            this.botãoFoto.Click += new System.EventHandler(this.button1_Click);
            // 
            // Foto
            // 
            this.Foto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Foto.Image = ((System.Drawing.Image)(resources.GetObject("Foto.Image")));
            this.Foto.Location = new System.Drawing.Point(14, 27);
            this.Foto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Foto.Name = "Foto";
            this.Foto.Size = new System.Drawing.Size(163, 172);
            this.Foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Foto.TabIndex = 3;
            this.Foto.TabStop = false;
            // 
            // caixaEmail
            // 
            this.caixaEmail.Location = new System.Drawing.Point(188, 128);
            this.caixaEmail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaEmail.Name = "caixaEmail";
            this.caixaEmail.Size = new System.Drawing.Size(260, 22);
            this.caixaEmail.TabIndex = 1;
            // 
            // caixaNascimento
            // 
            this.caixaNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.caixaNascimento.Location = new System.Drawing.Point(303, 174);
            this.caixaNascimento.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaNascimento.MaxDate = new System.DateTime(2024, 12, 31, 0, 0, 0, 0);
            this.caixaNascimento.Name = "caixaNascimento";
            this.caixaNascimento.Size = new System.Drawing.Size(145, 22);
            this.caixaNascimento.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 69);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero";
            // 
            // caixaNumero
            // 
            this.caixaNumero.Location = new System.Drawing.Point(322, 86);
            this.caixaNumero.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.caixaNumero.Name = "caixaNumero";
            this.caixaNumero.Size = new System.Drawing.Size(126, 22);
            this.caixaNumero.TabIndex = 1;
            // 
            // botãoAtualizar
            // 
            this.botãoAtualizar.Location = new System.Drawing.Point(413, 215);
            this.botãoAtualizar.Name = "botãoAtualizar";
            this.botãoAtualizar.Size = new System.Drawing.Size(87, 23);
            this.botãoAtualizar.TabIndex = 8;
            this.botãoAtualizar.Text = "ATUALIZAR";
            this.botãoAtualizar.UseVisualStyleBackColor = true;
            this.botãoAtualizar.Click += new System.EventHandler(this.botãoAtualizar_Click);
            // 
            // AltDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 253);
            this.Controls.Add(this.botãoAtualizar);
            this.Controls.Add(this.caixaNascimento);
            this.Controls.Add(this.botãoRemover);
            this.Controls.Add(this.botãoFoto);
            this.Controls.Add(this.Foto);
            this.Controls.Add(this.caixaEmail);
            this.Controls.Add(this.caixaNumero);
            this.Controls.Add(this.caixaCurso);
            this.Controls.Add(this.caixaEscola);
            this.Controls.Add(this.caixaNome);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelNomeESC);
            this.Controls.Add(this.labelCurso);
            this.Controls.Add(this.labelSobrenome);
            this.Controls.Add(this.labelDatNasci);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.caixaID);
            this.Controls.Add(this.labelID);
            this.Font = new System.Drawing.Font("JetBrains Mono", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AltDados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Minha Conta";
            this.Load += new System.EventHandler(this.Conta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Foto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.TextBox caixaID;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.TextBox caixaNome;
        private System.Windows.Forms.Label labelDatNasci;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelCurso;
        private System.Windows.Forms.TextBox caixaCurso;
        private System.Windows.Forms.PictureBox Foto;
        private System.Windows.Forms.Button botãoFoto;
        private System.Windows.Forms.Button botãoRemover;
        private System.Windows.Forms.Label labelSobrenome;
        private System.Windows.Forms.Label labelNomeESC;
        private System.Windows.Forms.TextBox caixaEscola;
        private System.Windows.Forms.TextBox caixaEmail;
        private System.Windows.Forms.DateTimePicker caixaNascimento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox caixaNumero;
        private System.Windows.Forms.Button botãoAtualizar;
    }
}