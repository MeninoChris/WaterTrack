﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WaterTrack
{
    public partial class Mapa_ESC : Form
    {
        public Mapa_ESC()
        {
            InitializeComponent();
        }

        private void labelSair_Click(object sender, EventArgs e)
        {

            this.Hide();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
