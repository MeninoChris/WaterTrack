﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WaterTrack
{
    public partial class Fornecedor : Form
    {
        public Fornecedor()
        {
            InitializeComponent();
        }

        private void GerarFornecedores()
        {
            // Lista de feedbacks
            List<string> feedbacks = new List<string>()
            {
                "AquaLive: 1223564825663",
                "HidroWay: 5166153465416"
            };

            // Embaralha a lista de feedbacks
            Random random = new Random();
            List<string> feedbacksAleatorios = new List<string>();

            // Pega três feedbacks aleatórios da lista
            for (int i = 0; i < 1; i++)
            {
                int indexAleatorio = random.Next(feedbacks.Count);
                feedbacksAleatorios.Add(feedbacks[indexAleatorio]);
                feedbacks.RemoveAt(indexAleatorio); // Remove o feedback já utilizado
            }

            // Exibe os feedbacks nas labels
            Forn.Text = feedbacksAleatorios[0].Split(':')[0]; // Assunto do primeiro feedback
            Cont.Text = feedbacksAleatorios[0].Split(':')[1]; // Autor do primeiro feedback
        }

        private void labelSair_Click(object sender, EventArgs e)
        {

            this.Hide();

        }

        private void Fornecedor_Load(object sender, EventArgs e)
        {

            GerarFornecedores();

        }
    }
}
